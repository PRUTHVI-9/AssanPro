package com.example.cms_app.view

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.cms_app.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class Splash_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_splash)

        lifecycleScope.launch {
            delay(2000) // 2 seconds delay
            startActivity(Intent(this@Splash_Activity, Login_Activity::class.java))
            finish()
        }
    }
}