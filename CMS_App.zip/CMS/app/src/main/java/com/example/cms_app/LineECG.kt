package com.example.cms_app

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.opengles.GL10

class LineECG {

    private var totalPoints = 0
    private var buffer: FloatBuffer? = null

    private var writeIndex = 0
    private var filled = 0

    private var centerY = 0f
    private var amplitude = 0.2f

    fun initialize(
        points: Int,
        upperBand: Boolean,
        pixelPerSample: Float,
        screenWidth: Int
    ) {

        totalPoints = points
        centerY = if (upperBand) 0.6f else -0.2f

        buffer = ByteBuffer.allocateDirect(totalPoints * 3 * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()

        for (i in 0 until totalPoints) {

            val xPixel = i * pixelPerSample
            val x = -1f + 2f * (xPixel / screenWidth)

            buffer!!.put(i * 3, x)
            buffer!!.put(i * 3 + 1, centerY)
            buffer!!.put(i * 3 + 2, 0f)
        }

        writeIndex = 0
        filled = 0
    }

    fun addSample(value: Float) {

        buffer ?: return

        val gain = 0.001f
        val scaled = value * gain
        val y = centerY + scaled * amplitude

        buffer!!.put(writeIndex * 3 + 1, y)

        writeIndex = (writeIndex + 1) % totalPoints
        if (filled < totalPoints) filled++
    }

    fun draw(gl: GL10) {

        if (buffer == null || filled < 2) return

        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY)
        gl.glLineWidth(2f)

        buffer!!.position(0)
        gl.glVertexPointer(3, GL10.GL_FLOAT, 0, buffer)

        if (filled < totalPoints) {
            // warmup phase
            gl.glDrawArrays(GL10.GL_LINE_STRIP, 0, filled)
        } else {
            // circular drawing

            //  from writeIndex to end
            gl.glDrawArrays(
                GL10.GL_LINE_STRIP,
                writeIndex,
                totalPoints - writeIndex
            )

            // Part 2: from start to writeIndex
            if (writeIndex > 0) {
                gl.glDrawArrays(
                    GL10.GL_LINE_STRIP,
                    0,
                    writeIndex
                )
            }
        }

        gl.glDisableClientState(GL10.GL_VERTEX_ARRAY)
    }
}