package com.example.cms_app.view.Fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.fragment.app.Fragment
import com.example.cms_app.R
import com.example.cms_app.databinding.FragmentEventBinding

class EventFragment : Fragment(R.layout.fragment_event) {

    private lateinit var binding: FragmentEventBinding


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<ImageView>(R.id.menu_icon).setOnClickListener { (activity as Combine_Main_Activity).openDrawer() }

    }
}