package com.example.cms_app.Helper
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.hivemq.client.mqtt.MqttClient
import com.hivemq.client.mqtt.datatypes.MqttQos
import com.hivemq.client.mqtt.mqtt3.Mqtt3AsyncClient
import java.nio.charset.StandardCharsets

class MqttHelper(
    private val brokerHost: String,
    private val brokerPort: Int,
    private val topics: List<String>,
    private val onJsonReceived: (topic: String, payload: String) -> Unit
) {
    private val clientId = "AndroidClient-" + System.currentTimeMillis()
    private val client: Mqtt3AsyncClient = MqttClient.builder()
        .identifier(clientId)
        .serverHost(brokerHost)
        .serverPort(brokerPort)
        .useMqttVersion3()
        .buildAsync()

    fun connect(
        username: String? = null,
        password: String? = null,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit
    ) {
        val connectBuilder = client.connectWith()

        if (username != null && password != null) {
            connectBuilder.simpleAuth()
                .username(username)
                .password(password.toByteArray())
                .applySimpleAuth()
        }

        connectBuilder.send().whenComplete { _, throwable ->
            if (throwable == null) {
//                Log.i("MQTT", "Connected -> subscribing to $topics")

                subscribeAll()

                onSuccess()
            } else {
//                Log.e("MQTT_failed", "Connect failed: ${throwable.message}")
                onFailure(throwable.message ?: "Connection failed")
            }
        }
    }

    private fun subscribeAll() {
        topics.forEach { topic ->
            client.subscribeWith()
                .topicFilter(topic)
                .qos(MqttQos.AT_LEAST_ONCE)
                .callback { publish ->
                    val payload = String(publish.payloadAsBytes, StandardCharsets.UTF_8)
//                    Log.d("MQTT2", "Message ($topic): $payload")
                    Handler(Looper.getMainLooper()).post {
                        onJsonReceived(topic, payload)
                    }
                }
                .send()
        }
    }
    fun subscribe(topic: String) {

        client.subscribeWith()
            .topicFilter(topic)
            .qos(MqttQos.AT_LEAST_ONCE)
            .callback { publish ->

                val payload = String(
                    publish.payloadAsBytes,
                    StandardCharsets.UTF_8
                )

                Log.d(
                    "MQTT_SUBSCRIBE",
                    "Message ($topic): $payload"
                )

                Handler(Looper.getMainLooper()).post {

                    onJsonReceived(topic, payload)
                }
            }
            .send()
            .whenComplete { _, throwable ->

                if (throwable == null) {

                    Log.d(
                        "MQTT_SUBSCRIBE",
                        "Subscribed Successfully -> $topic"
                    )

                } else {

                    Log.e(
                        "MQTT_SUBSCRIBE",
                        "Subscribe Failed: ${throwable.message}"
                    )
                }
            }
    }

    fun publish(topic: String, message: String) {
        client.publishWith()
            .topic(topic)
            .payload(message.toByteArray(StandardCharsets.UTF_8))
            .qos(MqttQos.AT_LEAST_ONCE)
            .send()
            .whenComplete { _, throwable ->
                if (throwable == null){
                    Log.d("MQTT_PUBLISH", "Sent → [$topic]: $message")

                }
                else{
                    Log.e("MQTT_PUBLISH", "Failed: ${throwable.message}")
                }
            }
    }

    fun disconnect()  {
        try {
            client.disconnect()
        } catch (e: Exception) {
//            Log.e("MQTT", "Disconnect failed: ${e.message}")
        }
    }
}
