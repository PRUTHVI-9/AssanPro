package com.example.cms_app.view

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.cms_app.Helper.MqttHelper
import com.example.cms_app.R
import com.example.cms_app.databinding.ActivityGlsurfaceBinding
import com.example.cms_app.utilis.AlarmPlayer
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


class GLSurfaceActivity : AppCompatActivity() {

    /*lateinit var binding: ActivityGlsurfaceBinding
    private lateinit var glSurfaceView1: OpenGLSurfaceView1   // ECG
    private lateinit var glSurfaceView2: OpenGLSurfaceView2   // SpO2
    private lateinit var glSurfaceView3: OpenGLSurfaceView3   // RESP
    lateinit var tvECG : TextView
    lateinit var tvSPO2 : TextView
    lateinit var tvRESP : TextView
    lateinit var time : TextView
    lateinit var patientName : TextView

    private var mqttManager: MqttHelper? = null
    private var lastSpo2Value: Int? = null

    private lateinit var clockHandler: Handler
    private lateinit var clockRunnable: Runnable

    private  val HR_HIGH_LIMIT = 100
    private var firstEcgArraySkipped = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_glsurface)

        binding = ActivityGlsurfaceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ensureConfigFolder()
        initViews()
        initMqtt()
        startClock()

        val patient = intent.getStringExtra("patient_name")?:""
        binding.patientName.setText(patient)

    }

    private fun initViews() {
        glSurfaceView1 = findViewById(R.id.glsurfaceview)
        glSurfaceView2 = findViewById(R.id.glsurfaceview2)
        glSurfaceView3 = findViewById(R.id.glsurfaceview3)
        tvECG = findViewById(R.id.ecgval)
        tvSPO2 = findViewById(R.id.spo2val)
        tvRESP = findViewById(R.id.respval)
        time = findViewById(R.id.time)
    }


    private fun initMqtt() {
        val topic = intent.getStringExtra("Topic") ?: "test/topic/full"
        val broker_Host = intent.getStringExtra("brokerHost") ?: ""
        val broker_port = intent.getIntExtra("brokerport",1883)

        mqttManager = MqttHelper(
            brokerHost = broker_Host,
//            brokerHost = "103.83.110.98",
            brokerPort = broker_port,
            topics = listOf(topic)
        ) { t, msg ->
            handleJSON(msg)
        }
        mqttManager?.connect()
    }


    *//*private fun initMqtt() {
        val topic = intent.getStringExtra("Topic") ?: "test/topic/full"

        val config = ConfigManager.load(this)

        val ip = config.getString("broker_ip")
        val port = config.getInt("broker_port")
//        val topic = config.getString("topic")

        mqttManager = MqttHelper(
            brokerHost = ip,
            brokerPort = port,
            topics = listOf(topic)
        ) { t, msg ->
            handleJSON(msg)
        }

        mqttManager?.connect()
    }*//*


    // ---------------------- MASTER JSON HANDLER ----------------------


     private fun handleJSON(msg: String) {
         try {
             val root = JSONObject(msg)
             handleECG(root)
             handleSPO2(root)
             handleRESP(root)
         } catch (e: Exception) {
             Log.e("JSON_ERROR", e.toString())
         }
     }

    // ------------------------- ECG -------------------------

  *//*  private fun handleECG(root: JSONObject) {
        val ecg = root.optJSONObject("ecg") ?: return
        val hr = ecg.optInt("hr",-1)    //text

        // UI update
        if (hr >= 0) {
            runOnUiThread {
                tvECG.text = hr.toString()
            }
            onHrRecived(this,hr)      //alaram
        }
        val wf = ecg.optJSONObject("waveform") ?: return
        val leadI = wf.optJSONArray("I") ?: return
        Log.d("leadI", "handleECG: $leadI")

        for (i in 0 until leadI.length()) {
            val value = leadI.getDouble(i).toFloat()
            Log.d("lead", "ECG: $value")

            glSurfaceView1.queueEvent {     //run GL thread
                glSurfaceView1.adddata(value)
                Log.d("ECG", "handleECG: $value")
            }
        }
    }
*//*

    private fun handleECG(root: JSONObject) {
        val ecg = root.optJSONObject("ecg") ?: return
        val hr = ecg.optInt("hr", -1)

        if (hr >= 0) {
            runOnUiThread {
                tvECG.text = hr.toString()
            }
         //   onHrRecived(this, hr)
        }

        val wf = ecg.optJSONObject("waveform") ?: return
        val leadI = wf.optJSONArray("I") ?: return
        Log.d("ECG_PACKET", "ECG packet sample count = ${leadI.length()}")

        //  SKIP FIRST ARRAY COMPLETELY
        if (!firstEcgArraySkipped) {
            firstEcgArraySkipped = true
            Log.d("ECG", "First ECG array skipped")
            return
        }

        //  AFTER FIRST ARRAY — NORMAL DRAW
        for (i in 0 until leadI.length()) {
            val value = leadI.getDouble(i).toFloat()

            glSurfaceView1.queueEvent {
                glSurfaceView1.adddata(value)
                Log.d("ecgvalue", "handleECG: $value")
            }
        }
    }


    //alarm set
    fun onHrRecived(context: Context, hr :Int){
        if (hr > HR_HIGH_LIMIT){
            AlarmPlayer.start(context)
        }
        else{
            AlarmPlayer.stop()
        }
    }


    // ------------------------- SpO2 -------------------------
    private fun handleSPO2(root: JSONObject) {
        val spo2 = root.optJSONObject("spo2") ?: return
        val spo2val = spo2.optInt("value",-1)

        if (spo2val > 0 ){
            runOnUiThread {
                tvSPO2.text = spo2val.toString()
            }
        }

        val wf = spo2.optJSONArray("waveform") ?: return
        Log.d("SPO2_PACKET", "SPO2 packet sample count = ${wf.length()}")


        for (i in 0 until wf.length()) {
            val value = wf.getDouble(i).toFloat()

            glSurfaceView2.queueEvent {
                glSurfaceView2.addDataPoint(value)
                Log.d("SPO2value", "handleSPO2: $value")

            }
        }
    }


    // ------------------------- RESP -------------------------
    private fun handleRESP(root: JSONObject) {
        val resp = root.optJSONObject("resp") ?: return
        val respval = resp.optInt("rr",-1)
        if (respval > 0){
            runOnUiThread {
                tvRESP.text  = respval.toString()
            }
        }
        val wf = resp.optJSONArray("waveform") ?: return
        Log.d("RR_packet", "handleRESP: ${wf.length()}")

        for (i in 0 until wf.length()) {
            val value = wf.getDouble(i).toFloat()

            glSurfaceView3.queueEvent {
                glSurfaceView3.addRespData(value)
                Log.d("Resp", "handleRESP: $value")
            }
        }
    }

    private fun startClock(){
        clockHandler = Handler(Looper.getMainLooper())

        clockRunnable = object : Runnable{
            override fun run() {
                val currentTime = SimpleDateFormat(
                    "HH:mm:ss",
                    Locale.getDefault()
                ).format(Date())
                time.text = currentTime
                clockHandler.postDelayed(this,1000)
            }
        }
        clockHandler.post(clockRunnable)
    }

    override fun onResume() {
        super.onResume()
        glSurfaceView1.onResume()
        glSurfaceView2.onResume()
        glSurfaceView3.onResume()
    }
      override fun onPause() {
          glSurfaceView1.onPause()
          glSurfaceView2.onPause()
          glSurfaceView3.onPause()
          super.onPause()
      }

    override fun onDestroy() {
        mqttManager?.disconnect()
        super.onDestroy()
    }

    private fun ensureConfigFolder() {
        val dir = File(getExternalFilesDir(null), "CMS")
        if (!dir.exists()) {
            dir.mkdirs()
        }
    }*/
}
