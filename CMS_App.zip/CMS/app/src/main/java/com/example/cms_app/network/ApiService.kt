package com.example.cms_app.network

import com.example.cms_app.data.model.LoginResponse
import com.example.cms_app.network.Loginrequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.Headers
import retrofit2.http.POST

interface ApiService {
    @FormUrlEncoded
    @POST("")
    suspend fun login(
        @Body loginrequest: Loginrequest
    ): Response<LoginResponse>
}