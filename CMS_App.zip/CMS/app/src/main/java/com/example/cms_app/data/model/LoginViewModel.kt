package com.example.cms_app.data.model

import android.util.Log
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cms_app.Helper.MqttHelper
import com.example.cms_app.repository.MainRepository
import com.example.cms_app.utilis.MqttConfig
import com.example.cms_app.utilis.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor() : ViewModel() {

    val result = MutableLiveData<UiState<LoginResponse>>()

    fun login1(userId: String, pass: String) {

        result.postValue(UiState.Loading)

        val topics = MqttConfig.getTopics(userId)

        val mqttHelper = MqttHelper(
            brokerHost = MqttConfig.BROKER_IP,
            brokerPort = MqttConfig.BROKER_PORT,
            topics = topics
        ) { topic, payload ->
            Log.d("MQTT_DATA", "Topic: $topic\nPayload: $payload")
        }

        mqttHelper.connect(
            username = userId,
            password = pass,
            onSuccess = {
                result.postValue(
                    UiState.Success(
                        LoginResponse(true, "Login Successful", userId)
                    )
                )
            },
            onFailure = {
                result.postValue(
                    UiState.Error("Invalid username or password")
                )
            }
        )
    }
}