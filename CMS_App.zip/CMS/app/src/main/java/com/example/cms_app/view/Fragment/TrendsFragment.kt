package com.example.cms_app.view.Fragment

import android.os.Bundle
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.cms_app.data.model.MqttViewModel
import com.example.cms_app.databinding.FragmentTrendsBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.os.Handler

class TrendsFragment : Fragment() {

    private var _binding: FragmentTrendsBinding? = null
    private val binding get() = _binding!!

    private lateinit var mqttViewModel: MqttViewModel

    private val handler = Handler(Looper.getMainLooper())

    private val runnable = object : Runnable {
        override fun run() {
            loadTrend()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTrendsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)
        mqttViewModel = ViewModelProvider(requireActivity())[MqttViewModel::class.java]
    }

    override fun onResume() {
        super.onResume()
        handler.post(runnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(runnable)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun loadTrend() {

        val data = mqttViewModel.getLastMinData()

        // clear old
        binding.timeHeader.removeAllViews()
        binding.hrRow.removeAllViews()
        binding.spo2Row.removeAllViews()
        binding.nibpRow.removeAllViews()
        binding.rrRow.removeAllViews()

        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

        data.forEach { trend ->
            val time = sdf.format(Date(trend.time))

            binding.timeHeader.addView(createCell(time))
            binding.hrRow.addView(createCell(trend.hr.toString()))
            binding.spo2Row.addView(createCell(trend.spo2.toString()))
            binding.nibpRow.addView(createCell(trend.nibp))
            binding.rrRow.addView(createCell(trend.rr.toString()))
        }
    }

    private fun createCell(text: String): TextView {
        return TextView(requireContext()).apply {
            layoutParams = LinearLayout.LayoutParams(150, LinearLayout.LayoutParams.MATCH_PARENT)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            this.text = text
        }
    }
}