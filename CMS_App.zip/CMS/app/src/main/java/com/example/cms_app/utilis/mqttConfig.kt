package com.example.cms_app.utilis

import android.content.Context


object MqttConfig {
//    const val BROKER_IP = "103.83.110.98"
      const val BROKER_IP = "192.168.1.82"
//    const val BROKER_IP = "192.168.100.45"
      const val BROKER_PORT = 1883


    fun getDoctorName(userid : String): String{
        val captialized = userid.replaceFirstChar { it.uppercase() }
        return "Doctor$captialized"
    }

    fun getTopics(userid: String): List<String>{
        val doctorName = getDoctorName(userid)
        val topics = mutableListOf<String>()
        for (i in 1..16){
            topics.add("ICU1/$doctorName/Bed$i/full")
            topics.add("ICU1/$doctorName/Bed$i/vitals")
        }
        return topics
    }
}
