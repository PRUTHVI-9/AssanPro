package com.example.cms_app.utilis

object CursorSync {
    @Volatile
    var index = 0
    const val totalPoints = 425

    const val STEP = 2   //  SPEED CONTROL (increase = faster)
}
