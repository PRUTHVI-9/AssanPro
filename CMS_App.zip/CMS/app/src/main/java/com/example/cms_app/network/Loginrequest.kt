package com.example.cms_app.network

import com.google.gson.annotations.SerializedName

class Loginrequest (
    @SerializedName("user_id")
    val userId: String,
    @SerializedName("password")
    val password: String
)