package com.example.cms_app.view

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.cms_app.data.model.LoginViewModel
import com.example.cms_app.data.model.MqttViewModel
import com.example.cms_app.databinding.ActivityLogin2Binding
import com.example.cms_app.service.MqttForegroundService
import com.example.cms_app.utilis.UiState
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class Login_Activity : AppCompatActivity() {

    private lateinit var binding: ActivityLogin2Binding
    private lateinit var viewModel: LoginViewModel
    private lateinit var mqttViewModel: MqttViewModel

    private var userId: String = ""
    private var password: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(
                arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                101
            )
        }

        binding = ActivityLogin2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[LoginViewModel::class.java]
        mqttViewModel = ViewModelProvider(this)[MqttViewModel::class.java]

        val sharedPref = getSharedPreferences("Sharedpref", MODE_PRIVATE)

        if (!sharedPref.contains("firstRunDone")) {
            sharedPref.edit().clear().apply()
            sharedPref.edit().putBoolean("firstRunDone", true).apply()
        }

        val isLoggedIn = sharedPref.getBoolean("isLoggedIn", false)

        // AUTO LOGIN
        if (isLoggedIn) {

            val empId = sharedPref.getString("empId", "") ?: ""
            val pass = sharedPref.getString("password", "") ?: ""

            if (empId.isNotEmpty() && pass.isNotEmpty()) {

                // Foreground Service only
                startMqttService(empId, pass)

                // Main MQTT for dashboard data
                mqttViewModel.startMqtt(empId, pass, this)
                val intent = Intent(this, Dashboard_Activty::class.java)
                intent.putExtra("userId", empId)
                startActivity(intent)
                finish()
                return
            }
        }

        // LOGIN BUTTON
        binding.login.setOnClickListener {

            if (!isInternetAvailable()) {
                Toast.makeText(this, "No internet connection", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            userId = binding.email.text.toString().trim()
            password = binding.password.text.toString().trim()

            if (userId.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            viewModel.login1(userId, password)
        }

        observeLogin()
    }

    // START FOREGROUND SERVICE
    private fun startMqttService(empId: String, pass: String) {

        val intent = Intent(this, MqttForegroundService::class.java)
        intent.putExtra("userId", empId)
        intent.putExtra("password", pass)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }

        Log.e("SERVICE", "Foreground Service Started")
    }

    // LOGIN OBSERVER
    private fun observeLogin() {

        viewModel.result.observe(this) {

            when (it) {

                is UiState.Loading -> {
                    binding.login.visibility = View.GONE
                    binding.progressbar.visibility = View.VISIBLE
                }

                is UiState.Success -> {

                    binding.login.visibility = View.VISIBLE
                    binding.progressbar.visibility = View.GONE

                    val empId = it.data?.empId ?: ""

                    val sharedPref = getSharedPreferences("Sharedpref", MODE_PRIVATE)

                    with(sharedPref.edit()) {
                        putBoolean("isLoggedIn", true)
                        putString("empId", empId)
                        putString("password", password)   // IMPORTANT
                        apply()
                    }

                    // Start service
                    startMqttService(empId, password)

                    // Start dashboard mqtt
                    mqttViewModel.startMqtt(empId, password, this)

                    val intent = Intent(this, Dashboard_Activty::class.java)
                    intent.putExtra("userId", empId)
                    startActivity(intent)
                    finish()
                }

                is UiState.Error -> {

                    binding.login.visibility = View.VISIBLE
                    binding.progressbar.visibility = View.GONE

                    Toast.makeText(this, it.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // INTERNET CHECK
    private fun isInternetAvailable(): Boolean {

        val connectivityManager =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        val network = connectivityManager.activeNetwork ?: return false

        val capabilities =
            connectivityManager.getNetworkCapabilities(network) ?: return false

        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }
}