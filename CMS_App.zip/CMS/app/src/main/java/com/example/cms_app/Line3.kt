package com.example.cms_app

import android.opengl.GLES20
import android.util.Log
import com.example.cms_app.utilis.CursorSync
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max
import kotlin.math.min

/*

class Line3 {

    private val totalPoints = 425
    private val vertexBuffer: FloatBuffer

    private var writeIndex = 0
    private var filledPoints = 0

    init {
        vertexBuffer = ByteBuffer
            .allocateDirect(totalPoints * 3 * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()

        // flat line init
        for (i in 0 until totalPoints) {
            val x = -1f + 2f * i / (totalPoints - 1)
            vertexBuffer.put(i * 3, x)
            vertexBuffer.put(i * 3 + 1, 0f)
            vertexBuffer.put(i * 3 + 2, 0f)
        }
    }

    // ---------------- ADD RESP DATA ----------------
    fun addDataPoint(value: Float) {

        val scaled = value / 10f
        val gain = 0.001f
        val y = (scaled * gain).coerceIn(-1f, 1f)

        val offset = writeIndex * 3
        vertexBuffer.put(offset + 1, y)

        if (filledPoints < totalPoints) filledPoints++
        writeIndex = (writeIndex + 1) % totalPoints
    }

    // ---------------- DRAW ----------------
    fun draw(gl: GL10) {

        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY)
        gl.glLineWidth(2f)

        // RESP waveform color (yellowish)
        gl.glColor4f(1f, 1f, 0.2f, 1f)

        vertexBuffer.position(0)
        gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuffer)
        gl.glDrawArrays(GL10.GL_LINE_STRIP, 0, filledPoints)

        gl.glDisableClientState(GL10.GL_VERTEX_ARRAY)
    }
}
*/



class Line3 {

    private val totalPoints = 1000
    private val vertexBuffer: FloatBuffer

    private var writeIndex = 0
    private var filledPoints = 0

    private var minVal = Float.MAX_VALUE
    private var maxVal = -Float.MAX_VALUE

    // ---- warm-up ----
    private var warmupCount = 0
    private val WARMUP_LIMIT = 100   // ~2 sec @110Hz

    init {
        vertexBuffer = ByteBuffer
            .allocateDirect(totalPoints * 3 * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()

        for (i in 0 until totalPoints) {
            val x = -1f + 2f * i / (totalPoints - 1)
            vertexBuffer.put(i * 3, x)
            vertexBuffer.put(i * 3 + 1, 0f)
            vertexBuffer.put(i * 3 + 2, 0f)
        }
    }


    fun addSample(value: Float) {
        minVal = min(minVal, value)
        maxVal = max(maxVal, value)

        val amp = max(1f, maxVal - minVal)
        val norm = (value - minVal) / amp
        val y = (norm - 0.5f) * 0.4f   // SpO₂ smaller amplitude

        vertexBuffer.put(writeIndex * 3 + 1, y)

        writeIndex = (writeIndex + 1) % totalPoints
        if (filledPoints < totalPoints) filledPoints++
        onSampleReceived()
    }

    fun draw(gl: GL10) {
        if (filledPoints < 2) return

        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY)
        gl.glLineWidth(2f)
        gl.glColor4f(1f, 1f, 0.2f, 1f)

        vertexBuffer.position(0)
        gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuffer)

        if (writeIndex > 1)
            gl.glDrawArrays(GL10.GL_LINE_STRIP, 0, writeIndex)

        if (filledPoints > writeIndex + 1)
            gl.glDrawArrays(
                GL10.GL_LINE_STRIP,
                writeIndex,
                filledPoints - writeIndex
            )

        gl.glDisableClientState(GL10.GL_VERTEX_ARRAY)
    }

    private var sampleCounter = 0
    private var lastTime = System.currentTimeMillis()

    fun onSampleReceived() {
        sampleCounter++

        val now = System.currentTimeMillis()
        if (now - lastTime >= 1000) {
            Log.d("SAMPLE_RATE_RR", "Samples per second RR= $sampleCounter")
            sampleCounter = 0
            lastTime = now
        }
    }
}
