package com.example.cms_app.view

import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.ViewModelProvider
import com.example.cms_app.Helper.MqttManager
import com.example.cms_app.OpenGLSurfaceViewCombined
import com.example.cms_app.R
import com.example.cms_app.data.model.MqttViewModel
import com.example.cms_app.databinding.ActivityCombineglsurfaceBinding
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import com.google.android.material.bottomsheet.BottomSheetDialog

class GLSurfaceCombineActivity : AppCompatActivity() {

    lateinit var binding: ActivityCombineglsurfaceBinding
    lateinit var glCombined: OpenGLSurfaceViewCombined
    lateinit var tvECG: TextView
    lateinit var tvSPO2: TextView
    lateinit var tvRESP: TextView
    lateinit var tvNIBP : TextView
    lateinit var time: TextView
    lateinit var tvAlarm: TextView
    private lateinit var mqttViewModel: MqttViewModel
    private var selectedTopic: String = ""
    private lateinit var clockHandler: Handler
    private lateinit var clockRunnable: Runnable
    private val alarmCache = mutableMapOf<String, Pair<Int, Long>>()
    private var alarmIndex = 0
    private val alarmHandler = Handler(Looper.getMainLooper())
    private var lastAlarmTime: Long = 0
    private val alarmHoldDuration = 2000L
    private var lastAlarmCode: Int? = null
    private lateinit var doctorName: String
    private lateinit var publishTopic: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

        enableEdgeToEdge()

        binding = ActivityCombineglsurfaceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        WindowCompat.setDecorFitsSystemWindows(window, false)

        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE}

        if (!isInternetAvailable()){
            Toast.makeText(this, "No Network Available", Toast.LENGTH_SHORT).show()
        }

        mqttViewModel = ViewModelProvider(this)[MqttViewModel::class.java]

        selectedTopic = intent.getStringExtra("Topic") ?: ""
        val patient = intent.getStringExtra("patient_name") ?: ""

        val sharedpref = getSharedPreferences(
            "Sharedpref",
            MODE_PRIVATE
        )

        doctorName = sharedpref.getString("empId", "") ?: ""
        publishTopic = selectedTopic.substringBeforeLast("/") + "/mobileToDesktop"
        binding.ivPrescription.setOnClickListener {

            showPrescriptionDialog()
        }
        binding.textPatientName.text = patient

        initViews()
        startClock()
        startAlarmRotation()
        observeMqtt()
    }

    private fun initViews() {
        tvECG = findViewById(R.id.ecgval)
        tvSPO2 = findViewById(R.id.spo2val)
        tvRESP = findViewById(R.id.respval)
        time = findViewById(R.id.time)
        glCombined = findViewById(R.id.glCombined)
        tvAlarm = findViewById(R.id.tvAlarm)
    }


    private fun observeMqtt() {
        MqttViewModel.mqttData.observe(this) { (topic, msg) ->

            val baseTopic = selectedTopic.substringBeforeLast("/")

            if (!topic.startsWith(baseTopic)) return@observe

            if (topic.endsWith("full")) {
                if (topic != selectedTopic) return@observe
                handleFullJson(msg)
            }
        }
    }


    private fun handleFullJson(msg: String) {
        try {
            val root = JSONObject(msg)
            val alarmsObj = root.optJSONObject("alarms")

            val hr = root.optInt("hr", -1)

            val hrLow = if (alarmsObj?.isNull("hr_low") == false) alarmsObj.optInt("hr_low") else null
            val hrHigh = if (alarmsObj?.isNull("hr_high") == false) alarmsObj.optInt("hr_high") else null

            if (hr > 0) {
                tvECG.text = hr.toString()
            }

            val currentTime = System.currentTimeMillis()

            if (hrLow != null) {
                lastAlarmTime = currentTime
                lastAlarmCode = hrLow
            } else if (hrHigh != null) {
                lastAlarmTime = currentTime
                lastAlarmCode = hrHigh
            }

            if (currentTime - lastAlarmTime <= alarmHoldDuration && lastAlarmCode != null) {
                stopBlinking(tvECG)
                setAlarmColor(tvECG, lastAlarmCode)
                startBlinkingSafe(tvECG)
            } else {
                stopBlinking(tvECG)
                tvECG.setBackgroundColor(Color.TRANSPARENT)
                tvECG.setTextColor(Color.GREEN)
            }

            val spo2Val = root.optJSONObject("spo2")?.optInt("value", -1) ?: -1
            if (spo2Val > 0) tvSPO2.text = spo2Val.toString()

            val rr = root.optJSONObject("resp")?.optInt("rr", -1) ?: -1
            if (rr > 0) tvRESP.text = rr.toString()


            val nibp = root.optJSONObject("nibp")
            val sys = nibp.optInt("mean" ,-1) ?: -1
            val dia = nibp.optInt("sys",-1) ?: -1
            val mean = nibp.optInt("mean", -1)?: -1

            if (sys > 0) { binding.NIBPSya.text = "$sys" }
            if (dia > 0){ binding.NIBPDia.text = "$dia"}


            alarmsObj?.keys()?.forEach { key ->
                val value = alarmsObj.optInt(key, -1)
                if (value != -1) {
                    alarmCache[key] = Pair(value, currentTime)
                }
            }

            handleECG(root)
            handleSPO2(root)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showPrescriptionDialog() {

        val bottomSheetDialog = BottomSheetDialog(this)

        val view = layoutInflater.inflate(
            R.layout.dialog_prescription,
            null
        )

        bottomSheetDialog.setContentView(view)

        val bottomSheet =
            bottomSheetDialog.findViewById<View>(
                com.google.android.material.R.id.design_bottom_sheet
            )

        bottomSheet?.setBackgroundColor(Color.TRANSPARENT)

        val edtPrescription =
            view.findViewById<EditText>(R.id.edtPrescription)

        val btnSave =
            view.findViewById<Button>(R.id.btnSave)

        val tvCount =
            view.findViewById<TextView>(R.id.tvCount)

        edtPrescription.addTextChangedListener(
            object : TextWatcher {

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(
                    s: CharSequence?,
                    start: Int,
                    before: Int,
                    count: Int
                ) {

                    tvCount.text =
                        "${s?.length ?: 0} / 5000"
                }

                override fun afterTextChanged(
                    s: Editable?
                ) {
                }
            })

        btnSave.setOnClickListener {

            val prescription =
                edtPrescription.text.toString().trim()

            if (prescription.isEmpty()) {

                edtPrescription.error =
                    "Enter prescription"

                return@setOnClickListener
            }

            try {

                val finalJson = JSONObject()

                finalJson.put(
                    "type",
                    "prescription"
                )

                finalJson.put(
                    "doctor",
                    doctorName
                )

                finalJson.put(
                    "prescription",
                    prescription
                )

                MqttManager.publish(
                    publishTopic,
                    finalJson.toString()
                )

                Log.e(
                    "PRESCRIPTION_JSON",
                    finalJson.toString()
                )

                Toast.makeText(
                    this,
                    "Prescription Sent",
                    Toast.LENGTH_SHORT
                ).show()

                edtPrescription.text.clear()

                bottomSheetDialog.dismiss()

            } catch (e: Exception) {

                Log.e(
                    "PRESCRIPTION_ERROR",
                    e.toString()
                )
            }
        }

        bottomSheetDialog.show()
    }


    private fun startAlarmRotation() {
        alarmHandler.postDelayed(object : Runnable {
            override fun run() {

                val currentTime = System.currentTimeMillis()
                val expiry = 5000

                val activeAlarms = alarmCache.filter {
                    currentTime - it.value.second <= expiry
                }

                if (activeAlarms.isEmpty()) {
                    tvAlarm.visibility = TextView.GONE
                } else {
                    tvAlarm.visibility = TextView.VISIBLE

                    val alarmList = activeAlarms.toList()
                    val safeIndex = alarmIndex % alarmList.size
                    val (name, pair) = alarmList[safeIndex]

                    tvAlarm.text = name.replace("_", " ").uppercase()
                    setAlarmColor(tvAlarm, pair.first)

                    alarmIndex = safeIndex + 1
                }

                alarmHandler.postDelayed(this, 1000)
            }
        }, 1000)
    }


    private fun setAlarmColor(view: TextView, code: Int?) {
        when (code) {
            0 -> {
                view.setBackgroundColor(Color.TRANSPARENT)
                view.setTextColor(Color.WHITE)
            }
            1 -> {
                view.setBackgroundColor(Color.parseColor("#03dbfc"))
                view.setTextColor(Color.BLACK)
            }
            2 -> {
                view.setBackgroundColor(Color.YELLOW)
                view.setTextColor(Color.BLACK)
            }
            3 -> {
                view.setBackgroundColor(Color.RED)
                view.setTextColor(Color.WHITE)
            }
            else -> {
                view.setBackgroundColor(Color.TRANSPARENT)
                view.setTextColor(Color.GREEN)
            }
        }
    }


    private fun handleECG(root: JSONObject) {
        val ecg = root.optJSONObject("ecg") ?: return
        val wf = ecg.optJSONObject("waveform") ?: return
        val leadI = wf.optJSONArray("I") ?: return
//        Log.d("ECG_PACKET", "ECG packet sample count = ${leadI.length()}")


        for (i in 0 until leadI.length()) {
            val value = leadI.getDouble(i).toFloat()
            binding.glCombined.queueEvent {
                binding.glCombined.addECG(value)
            }
        }
    }

    private fun handleSPO2(root: JSONObject) {
        val spo2 = root.optJSONObject("spo2") ?: return
        val wf = spo2.optJSONArray("waveform") ?: return
//        Log.d("SPO2_PACKET", "spo2 packet sample count = ${wf.length()}")

        if (wf.length() < 20) return


        for (i in 0 until wf.length()) {
            val value = wf.getDouble(i).toFloat()
            binding.glCombined.queueEvent {
                binding.glCombined.addSPO2(value)
            }
        }
    }

    private fun startClock() {
        clockHandler = Handler(Looper.getMainLooper())

        clockRunnable = object : Runnable {
            override fun run() {
                val currentTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                time.text = currentTime
                clockHandler.postDelayed(this, 1000)
            }
        }
        clockHandler.post(clockRunnable)
    }

    private fun startBlinkingSafe(view: TextView) {
        view.clearAnimation()

        val anim = AlphaAnimation(0.5f, 1.0f)
        anim.duration = 800
        anim.repeatMode = Animation.REVERSE
        anim.repeatCount = Animation.INFINITE

        view.startAnimation(anim)
    }

    private fun stopBlinking(view: TextView) {
        view.clearAnimation()
    }

    fun isInternetAvailable(): Boolean{
        val connectivityManager =  getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network)?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)

    }
    override fun onDestroy() {
        super.onDestroy()
        clockHandler.removeCallbacks(clockRunnable)
    }
}