package com.example.cms_app.data

data class TrendData(
    val time : Long,
    val hr : Int,
    val spo2 : Int,
    val rr : Int,
    val nibp : String
    )
