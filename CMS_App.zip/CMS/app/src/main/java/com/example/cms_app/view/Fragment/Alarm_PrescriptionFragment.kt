package com.example.cms_app.view.Fragment

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.cms_app.Helper.MqttManager
import com.example.cms_app.R
import com.example.cms_app.data.model.MqttViewModel
import org.json.JSONObject

class Alarm_PrescriptionFragment : Fragment() {

    private lateinit var etComment: EditText
    private lateinit var btnSubmit: Button
    private lateinit var tvCount: TextView
    private lateinit var doctorName: String
    private lateinit var bedNumber: String
    private lateinit var publishTopic: String
    private lateinit var subscribeTopic: String

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {

        val view = inflater.inflate(R.layout.fragment_alarm_presicription, container, false)

        etComment = view.findViewById(R.id.etComment)
        btnSubmit = view.findViewById(R.id.btnSubmit)
        tvCount = view.findViewById(R.id.tvCount)

        // SharedPreference
        val sharedpref = requireContext().getSharedPreferences("Sharedpref", AppCompatActivity.MODE_PRIVATE)

        doctorName = sharedpref.getString("empId", "") ?: ""

        // Intent Data
        bedNumber = requireActivity().intent.getStringExtra("bedNo") ?: ""

        val selectedTopic = requireActivity().intent.getStringExtra("Topic") ?: ""

        /*publishTopic = selectedTopic.substringBeforeLast("/") + "/mobileToDesktop"
        subscribeTopic = selectedTopic.substringBeforeLast("/") + "/desktopToMobile"*/
        publishTopic = selectedTopic.substringBeforeLast("/") + "/mobilePrescriptionToDesktop"
        subscribeTopic = selectedTopic.substringBeforeLast("/") + "/desktopToMobilePrescription"

        Log.e("PUBLISH_TOPIC", publishTopic)
        Log.e("SUBSCRIBE_TOPIC", subscribeTopic)

        // Subscribe
        MqttManager.subscribe(subscribeTopic)

        // Observe Desktop Response
        observeDesktopResponse()

        // Character Counter
        etComment.addTextChangedListener(object : TextWatcher {

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int)
            {
                tvCount.text = "${s?.length ?: 0} / 5000"
            }

            override fun afterTextChanged(s: Editable?) {}
        })

        // Submit Button
        btnSubmit.setOnClickListener {

            val comment = etComment.text.toString().trim()

            if (comment.isEmpty()) {

                etComment.error = "Please enter prescription"

                return@setOnClickListener
            }

            try {

                // JSON Create
                val finalJson = JSONObject()

                finalJson.put("type", "prescription")
                finalJson.put("bed", bedNumber)
                finalJson.put("doctor", doctorName)
                finalJson.put("prescription", comment)

                // Publish MQTT
                MqttManager.publish(publishTopic, finalJson.toString())

                Log.e("PRESCRIPTION_JSON", finalJson.toString())

                Toast.makeText(requireContext(), "Prescription Sent", Toast.LENGTH_SHORT).show()

            } catch (e: Exception) {

                Log.e("JSON_ERROR", e.toString())
            }
        }

        return view
    }

    // Desktop Response Observe
    private fun observeDesktopResponse() {

        MqttViewModel.mqttData.observe(viewLifecycleOwner) { (topic, msg) ->

            if (topic == subscribeTopic) {

                Log.e("MQTT_RESPONSE", msg)

                try {

                    val json = JSONObject(msg)

                    val status = json.optString("status")
                    val message = json.optString("message")

                    Log.e("STATUS", status)
                    Log.e("MessageRCD", message)

                    Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()

                    if (status.equals("success", true)) {
                        btnSubmit.text = "Submitted"
                    } else {
                       // btnSubmit.text = "Retry"
                    }

                } catch (e: Exception) {
                    Log.e("MQTT_ERROR", e.toString())
                }
            }
        }
    }
}