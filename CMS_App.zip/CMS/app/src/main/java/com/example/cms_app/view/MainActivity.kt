package com.example.cms_app.view

import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class MainActivity : AppCompatActivity() {
    val  database = FirebaseDatabase.getInstance()
    val ref = database.getReference("user")
}