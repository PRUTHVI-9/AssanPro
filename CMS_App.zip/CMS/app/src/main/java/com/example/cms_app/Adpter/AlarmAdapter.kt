package com.example.cms_app.Adpter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.cms_app.data.AlarmItem
import com.example.cms_app.databinding.ItemAlarmBinding

class AlarmAdapter(
    private val list: MutableList<AlarmItem>
) : RecyclerView.Adapter<AlarmAdapter.MyViewHolder>() {

    inner class MyViewHolder(val binding: ItemAlarmBinding)
        : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {

        val binding = ItemAlarmBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )

        return MyViewHolder(binding)
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        val item = list[position]

        with(holder.binding) {
            imgIcon.setImageResource(item.image)
            tvTitle.text = item.title
            tvUnit.text = item.unit

            tvLowValue.text = item.lowValue.toString()
            tvHighValue.text = item.highValue.toString()

            tvRange.text =
                "Range : ${item.minRange} - ${item.maxRange} ${item.unit}"

            val color = Color.parseColor(item.color)

            tvLowLabel.setTextColor(color)
            tvHighLabel.setTextColor(color)


            btnPlusLow.setOnClickListener {

                item.lowValue++

                tvLowValue.text =
                    item.lowValue.toString()
            }


            btnMinusLow.setOnClickListener {

                if (item.lowValue > item.minRange) {

                    item.lowValue--

                    tvLowValue.text =
                        item.lowValue.toString()
                }
            }


            btnPlusHigh.setOnClickListener {

                item.highValue++

                tvHighValue.text =
                    item.highValue.toString()
            }


            btnMinusHigh.setOnClickListener {

                if (item.highValue > item.lowValue) {

                    item.highValue--

                    tvHighValue.text =
                        item.highValue.toString()
                }
            }
        }
    }
}