package com.example.cms_app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.cms_app.R
import com.example.cms_app.view.MyBedActivity

class MqttForegroundService : Service() {

    private val serviceChannel = "service_channel_v5"

    override fun onCreate() {
        super.onCreate()

        createChannel()
        startMyForeground()
    }

    private fun startMyForeground() {

        val intent = Intent(this, MyBedActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }

        val pendingIntent = PendingIntent.getActivity(this, 9999,
            intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(this, serviceChannel)
            .setSmallIcon(R.drawable.ecgicon)
            .setContentTitle("CMS Running")
            .setContentText("Monitoring Patient Data")
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

        startForeground(1, notification)
    }

    private fun createChannel() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            val channel = NotificationChannel(serviceChannel, "Background Service", NotificationManager.IMPORTANCE_LOW)

            channel.description = "CMS Background Running Service"
            channel.setSound(null, null)
            channel.enableVibration(false)
            channel.enableLights(false)
            channel.lockscreenVisibility = Notification.VISIBILITY_PUBLIC

            val manager =
                getSystemService(NotificationManager::class.java)

            manager.createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        stopForeground(true)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}