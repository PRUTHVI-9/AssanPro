package com.example.cms_app.utilis


import android.content.Context
import android.util.Log
import org.json.JSONObject
import java.io.File


object ConfigManager {

    private const val CONFIG_DIR = "CMS"
    private const val CONFIG_FILE = "monitor_config.json"

    fun getConfigFile(context: Context): File {
        return File(
            context.getExternalFilesDir(null),
            "$CONFIG_DIR/$CONFIG_FILE"
        )
    }


    fun load(context: Context): JSONObject {

        readExternal(context)?.let { return it }
        readAssets(context)?.let { return it }

        return JSONObject().apply {
            put("broker_ip", "192.168.100.20")
            put("broker_port", 1883)
            put("topic", "test/topic/full")
        }
    }



    private fun readExternal(context: Context): JSONObject? {
        return try {
            val file = getConfigFile(context)

            Log.d("CFG", "Trying path: ${file.absolutePath}")
            Log.d("CFG", "Exists: ${file.exists()}")
            Log.d("CFG", "CanRead: ${file.canRead()}")

            if (!file.exists()) {
                Log.e("CFG", "Config file NOT FOUND")
                return null
            }

            val text = file.readText()
            Log.d("CFG", "Config content: $text")

            JSONObject(text)

        } catch (e: Exception) {
            Log.e("CFG", "Read error", e)
            null
        }
    }



    private fun readAssets(context: Context): JSONObject? {
        return try {
            val json = context.assets.open("CMS/config.json")
                .bufferedReader().use { it.readText() }
            JSONObject(json)
        } catch (e: Exception) {
            null
        }
    }
}