package com.example.cms_app.utilis

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import com.example.cms_app.R

object AlarmPlayer {

    private var mediaPlayer: MediaPlayer? = null

    fun start(context: Context) {
        if (mediaPlayer?.isPlaying == true) return

        val audioManager =
            context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

        // Force ALARM volume to max
        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
        audioManager.setStreamVolume(
            AudioManager.STREAM_ALARM,
            maxVol,
            0
        )

        mediaPlayer = MediaPlayer().apply {

            //  MODERN replacement of setAudioStreamType()
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )

            val afd = context.resources.openRawResourceFd(R.raw.hr_alarm)
            setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()

            isLooping = true
            prepare()
            start()
        }
    }

    fun stop() {
        mediaPlayer?.let {
            if (it.isPlaying) it.stop()
            it.release()
        }
        mediaPlayer = null
    }
}

/*


object AlarmPlayer {

    private var mediaPlayer: MediaPlayer? = null
    private var playCount = 0
    private const val MAX_PLAY = 2

    fun start(context: Context) {
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(context, R.raw.hr_alarm)
            mediaPlayer?.isLooping = false

            mediaPlayer?.setOnCompletionListener {
                playCount++

                if (playCount < MAX_PLAY) {
                    it.start()   // 🔁 पुन्हा वाजवा
                } else {
                    stop()       // 🛑 2 वेळा झालं → stop
                }
            }

            playCount = 0
            mediaPlayer?.start()
        }
    }

    fun stop() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
        playCount = 0
    }
}
*/
