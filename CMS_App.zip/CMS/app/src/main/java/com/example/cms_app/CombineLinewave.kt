package com.example.cms_app

import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.opengles.GL10

class CombineLinewave {

    enum class Type {
        ECG, SPO2
    }

    private var totalPoints = 0
    private var buffer: FloatBuffer? = null

    private var writeIndex = 0
    private var filled = 0

    private var centerY = 0f
    private var amplitude = 0.1f
    private var spo2Gain = 0.5f

    private var type = Type.ECG

    fun initialize(
        points: Int,
        upperBand: Boolean,
        pixelPerSample: Float,
        screenWidth: Int,
        waveType: Type
    ) {
        type = waveType
        totalPoints = points
//        Log.e("BUFFER_SIZE", "totalsize: $totalPoints", )
        centerY = if (upperBand) 0.4f else -0.5f   //change

        //added
        val sizeInBytes = totalPoints * 3 * 4
//        Log.d("BUFFER_SIZE", "Size = $sizeInBytes bytes")

        buffer = ByteBuffer.allocateDirect(totalPoints * 3 * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()

        for (i in 0 until totalPoints) {

            val xPixel = i * pixelPerSample
            val x = -1f + 2f * (xPixel / screenWidth)

            buffer!!.put(i * 3, x)
            buffer!!.put(i * 3 + 1, centerY)
            buffer!!.put(i * 3 + 2, 0f)
        }
        writeIndex = 0
        filled = 0
    }

    fun addSample(value: Float) {

        buffer ?: return

        val y = when (type) {

            Type.ECG -> {
                val gain = 0.005f
                val scaled = value * gain
                centerY + scaled * amplitude
            }

            /*Type.SPO2 -> {
                val minInput = 0f
                val maxInput = 300f

                val normalized =
                    ((value - minInput) / (maxInput - minInput))
                        .coerceIn(0f, 1f)

                val waveHeight = 0.15f
                centerY + (normalized - 0.005f) * waveHeight
            }*/

            Type.SPO2 -> {
                val minInput = 0f
                val maxInput = 300f

                val normalized =
                    ((value - minInput) / (maxInput - minInput))
                        .coerceIn(0f, 1f)

                centerY + (normalized - 0.5f) * spo2Gain
            }
        }
        buffer!!.put(writeIndex * 3 + 1, y)

        writeIndex = (writeIndex + 1) % totalPoints
        if (filled < totalPoints) filled++
    }

    fun draw(gl: GL10) {

        if (buffer == null || filled < 2) return

        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY)
        gl.glLineWidth(2f)

        buffer!!.position(0)
        gl.glVertexPointer(3, GL10.GL_FLOAT, 0, buffer)

        if (filled < totalPoints) {

            gl.glDrawArrays(GL10.GL_LINE_STRIP, 0, filled)

        } else {
            gl.glDrawArrays(
                GL10.GL_LINE_STRIP,
                writeIndex,
                totalPoints - writeIndex
            )

            if (writeIndex > 0) {
                gl.glDrawArrays(
                    GL10.GL_LINE_STRIP,
                    0,
                    writeIndex
                )
            }
        }
        gl.glDisableClientState(GL10.GL_VERTEX_ARRAY)
    }
}