// GLRenderer1.kt
package com.example.cms_app

import android.opengl.GLSurfaceView
import android.opengl.GLU
import java.util.concurrent.ConcurrentLinkedQueue
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10


class GLRenderer : GLSurfaceView.Renderer {

    private val line = Line()
    private val queue = ConcurrentLinkedQueue<Float>()

    // ---- timebase ----
    private val sampleIntervalNs = 4_000_000L   // 4ms = 250Hz
    private var lastSampleTime = 0L

    fun addPoint(value: Float) {
        queue.offer(value)
    }

    override fun onSurfaceCreated(gl: GL10, config: EGLConfig) {
        gl.glClearColor(0f, 0f, 0f, 1f)
        gl.glEnable(GL10.GL_LINE_SMOOTH)
        gl.glHint(GL10.GL_LINE_SMOOTH_HINT, GL10.GL_NICEST)
    }

    override fun onSurfaceChanged(gl: GL10, width: Int, height: Int) {
        gl.glViewport(0, 0, width, height)
        gl.glMatrixMode(GL10.GL_PROJECTION)
        gl.glLoadIdentity()
        GLU.gluOrtho2D(gl, -1f, 1f, -1f, 1f)
        gl.glMatrixMode(GL10.GL_MODELVIEW)
        gl.glLoadIdentity()
    }

    override fun onDrawFrame(gl: GL10) {
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT)

        val now = System.nanoTime()

        // ----  pacing loop ----
        while (now - lastSampleTime >= sampleIntervalNs) {
            queue.poll()?.let {
                line.addSample(it)
            }
            lastSampleTime += sampleIntervalNs
        }

        line.draw(gl)
    }
}


/*

class GLRenderer : GLSurfaceView.Renderer {

    private val line1 = line1()
    private val line2 = line2()

    private val ecgQueue = ConcurrentLinkedQueue<Float>()
    private val spo2Queue = ConcurrentLinkedQueue<Float>()

    private val sampleIntervalNs = 4_000_000L // 250Hz
    private var lastSampleTime = 0L

    private var started = false
    private var warmupCount = 0
    private val WARMUP_LIMIT = 350

    fun addEcg(value: Float) {
        ecgQueue.offer(value)
    }

    fun addSpo2(value: Float) {
        spo2Queue.offer(value)
    }

    override fun onSurfaceCreated(gl: GL10, config: EGLConfig) {
        lastSampleTime = System.nanoTime()
        gl.glClearColor(0f, 0f, 0f, 1f)
        gl.glEnable(GL10.GL_LINE_SMOOTH)
        gl.glHint(GL10.GL_LINE_SMOOTH_HINT, GL10.GL_NICEST)
    }

    override fun onSurfaceChanged(gl: GL10, w: Int, h: Int) {
        gl.glViewport(0, 0, w, h)
        gl.glMatrixMode(GL10.GL_PROJECTION)
        gl.glLoadIdentity()
        GLU.gluOrtho2D(gl, -1f, 1f, -1f, 1f)
        gl.glMatrixMode(GL10.GL_MODELVIEW)
        gl.glLoadIdentity()
    }

    override fun onDrawFrame(gl: GL10) {
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT)

        val now = System.nanoTime()

        while (now - lastSampleTime >= sampleIntervalNs) {

            val ecg = ecgQueue.poll()
            val spo2 = spo2Queue.poll()

            // ---- WARM-UP ----
            if (!started) {

                ecg?.let { line1.collectWarmup(it) }
                warmupCount++

                if (warmupCount >= WARMUP_LIMIT) {
                    line1.reset()
                    started = true
                    lastSampleTime = now
                }
                continue
            }

            // ---- SAME TICK UPDATE ----
            ecg?.let { line1.addSample(it) }
            spo2?.let { line2.addSample(it) }

            lastSampleTime += sampleIntervalNs
        }

        line1.draw(gl)
        line2.draw(gl)
    }
}
*/
