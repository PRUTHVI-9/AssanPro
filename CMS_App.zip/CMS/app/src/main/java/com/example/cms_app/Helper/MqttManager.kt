package com.example.cms_app.Helper

import android.util.Log
import com.example.cms_app.data.model.MqttViewModel
import com.example.cms_app.utilis.MqttConfig

object MqttManager {

    private var mqttHelper: MqttHelper? = null

    fun connect(
        userId: String,
        password: String,
        topics: List<String>,
        onMessage: (String, String) -> Unit
    ) {
        if (mqttHelper != null) {
            Log.d("MQTT_DEBUG", "Already connected to: ${MqttConfig.BROKER_IP}:${MqttConfig.BROKER_PORT}")
            return
        }

        val brokerUrl = "tcp://${MqttConfig.BROKER_IP}:${MqttConfig.BROKER_PORT}"

//        Log.d("MQTT_DEBUG", "Connecting with user: $userId")
//        Log.d("MQTT_DEBUG", "Broker URL: $brokerUrl")
//        Log.d("MQTT_DEBUG", "Subscribing topics: $topics")

        mqttHelper = MqttHelper(
            MqttConfig.BROKER_IP,
            MqttConfig.BROKER_PORT,
            topics
        ) { topic, payload ->

            onMessage(topic, payload)
            Log.d("MQTT_MESSAGE", "Received -> Topic: $topic Payload: $payload")

        }

        mqttHelper?.connect(
            username = userId,
            password = password,
            onSuccess = {
                Log.d("MQTT_CONNECT", " Connected Successfully to $brokerUrl")
            },
            onFailure = {
                Log.e("MQTT_CONNECT", " Connection Failed: $it")
            }
        )
    }

    fun publish(topic : String ,message : String){
        mqttHelper?.publish(topic,message)
    }
    fun subscribe(topic: String) {

        mqttHelper?.subscribe(topic)

        Log.e(
            "MQTT_SUBSCRIBE",
            "Subscribed Topic = $topic"
        )
    }


    fun disconnect() {
        if (mqttHelper != null) {
//            Log.d("MQTT_DISCONNECT", " Disconnected from tcp://${MqttConfig.BROKER_IP}:${MqttConfig.BROKER_PORT}")
            mqttHelper?.disconnect()
            mqttHelper = null
        } else {
//            Log.d("MQTT_DISCONNECT", "Already disconnected")
        }
    }
}

