package com.example.cms_app

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.opengles.GL10

class LineResp {

    private var totalPoints = 0
    private var buffer: FloatBuffer? = null

    private var writeIndex = 0
    private var filled = 0

    private var centerY = 0f

    fun initialize(
        points: Int,
        upperBand: Boolean,
        pixelPerSample: Float,
        screenWidth: Int
    ) {

        totalPoints = points
        centerY = if (upperBand) 0.6f else -0.2f

        buffer = ByteBuffer.allocateDirect(totalPoints * 3 * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()

        for (i in 0 until totalPoints) {

            val xPixel = i * pixelPerSample
            val x = -1f + 2f * (xPixel / screenWidth)

            buffer!!.put(i * 3, x)
            buffer!!.put(i * 3 + 1, centerY)
            buffer!!.put(i * 3 + 2, 0f)
        }

        writeIndex = 0
        filled = 0
    }

    fun addSample(value: Float) {

        buffer ?: return

        // ---- NORMALIZE RAW SPO2 ----
        // adjust this range according to your real raw data
        val minInput = 0f
        val maxInput = 300f    // <-- CHANGE if needed

        val normalized = ((value - minInput) / (maxInput - minInput))
            .coerceIn(0f, 1f)

        // ---- CONTROL HEIGHT HERE ----
        val waveHeight = 0.15f   // 0.15 small, 0.25 normal, 0.35 big

        val y = centerY + (normalized - 0.005f) * waveHeight

        buffer!!.put(writeIndex * 3 + 1, y)

        writeIndex = (writeIndex + 1) % totalPoints
        if (filled < totalPoints) filled++
    }

    fun draw(gl: GL10) {

        if (buffer == null || filled < 2) return

        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY)
        gl.glLineWidth(2f)

        buffer!!.position(0)
        gl.glVertexPointer(3, GL10.GL_FLOAT, 0, buffer)

        gl.glDrawArrays(GL10.GL_LINE_STRIP, 0, filled)

        gl.glDisableClientState(GL10.GL_VERTEX_ARRAY)
    }

}