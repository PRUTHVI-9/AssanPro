package com.example.cms_app.view.Fragment

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cms_app.Adpter.AlarmAdapter
import com.example.cms_app.Helper.MqttManager
import com.example.cms_app.R
import com.example.cms_app.data.AlarmItem
import com.example.cms_app.data.model.MqttViewModel
import com.example.cms_app.databinding.FragmentAlarmSettingBinding
import com.google.gson.JsonArray
import org.json.JSONObject
import org.json.JSONArray

class Alarm_settingFragment :
    Fragment(R.layout.fragment_alarm_setting) {

    private var _binding: FragmentAlarmSettingBinding? = null


    private val binding get() = _binding!!
    private lateinit var doctorName : String
    private lateinit var bedNumber : String
    private lateinit var publishTopic: String
    private lateinit var subscribeTopic : String


    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)

        _binding = FragmentAlarmSettingBinding.bind(view)
        val sharedpref = requireContext().getSharedPreferences("Sharedpref", AppCompatActivity.MODE_PRIVATE)
        doctorName = sharedpref.getString("empId", "") ?: ""


        bedNumber = requireActivity().intent.getStringExtra("bedNo") ?: ""
        Log.e("bedNumber", "onViewCreated: $bedNumber ,$doctorName")

        val selectedTopic = requireActivity().intent.getStringExtra("Topic") ?: ""
        publishTopic = selectedTopic.substringBeforeLast("/") + "/mobileToDesktop"
        subscribeTopic = selectedTopic.substringBeforeLast("/") + "/desktopToMobile"

        Log.e("MQTT_TOPIC", "Response: $subscribeTopic")
        Log.e("TOPIC", "Publish Topic = $publishTopic")

        MqttManager.subscribe(subscribeTopic)
        observeDesktopResponse()

        val alarmList = mutableListOf(
            AlarmItem(
                R.drawable.hr,
                "Heart Rate (HR)",
                "bpm",
                60,
                100,
                30,
                220,
                "#FF3B3B"
            ),

            AlarmItem(
                R.drawable.spo2,
                "SpO2",
                "%",
                90,
                100,
                70,
                100,
                "#2E5BFF"
            ),

            AlarmItem(
                R.drawable.rr,
                "Respiratory Rate (RR)",
                "rpm",
                12,
                20,
                5,
                60,
                "#00AA55"
            ),

            AlarmItem(
                R.drawable.blood_pressure,
                "Blood Pressure (SYS)",
                "mmHg",
                90,
                140,
                60,
                250,
                "#9C27B0"
            )
        )

        binding.recyclerAlarm.layoutManager =
            LinearLayoutManager(requireContext())

        binding.recyclerAlarm.adapter =
            AlarmAdapter(alarmList)

        binding.btnsave.setOnClickListener {
            val jsonArray = JSONArray()
            alarmList.forEach {
                item ->
                val jsonobject = JSONObject()
                jsonobject.put("name", item.title)
                jsonobject.put("unit", item.unit)
                jsonobject.put("low", item.lowValue)
                jsonobject.put("high",item.highValue)
                jsonobject.put("min", item.minRange)
                jsonobject.put("max", item.maxRange)

                jsonArray.put(jsonobject)
            }
            val finalJson = JSONObject()
            finalJson.put("type", "alarm_settings")
            finalJson.put("bed", bedNumber)
            finalJson.put("doctor", doctorName)
            finalJson.put("alarms", jsonArray)

            MqttManager.publish(publishTopic,finalJson.toString())

            Log.d("ALARM_JSON", finalJson.toString())

            Toast.makeText(requireContext(), "Alarm settings sent", Toast.LENGTH_SHORT).show()
        }
    }


    // RECEIVE DESKTOP RESPONSE
    private fun observeDesktopResponse() {

        MqttViewModel.mqttData.observe(viewLifecycleOwner) { (topic, msg) ->

            if (topic == subscribeTopic) {

                Log.e("MQTT_RESPONSE", msg)

                try {

                    val json = JSONObject(msg)
                    val status = json.optString("status")
                    val message = json.optString("message")

                    Log.e("STATUS", status)
                    Log.e("MESSAGE", message)

                    Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()

                    if (status.equals("success", true)) {
                        binding.btnsave.text = "Saved"
                    } else {
                       // binding.btnsave.text = "Retry"
                    }
                } catch (e: Exception) {

                    Log.e("MQTT_ERROR", e.toString()
                    )
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}