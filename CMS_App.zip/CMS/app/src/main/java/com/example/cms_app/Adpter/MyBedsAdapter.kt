package com.example.cms_app.Adpter

import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.cms_app.R
import com.example.cms_app.data.BedResponse

class MyBedsAdapter(
    private val onItemClick: (BedResponse) -> Unit
) : RecyclerView.Adapter<MyBedsAdapter.ViewHolder>() {

    private val allBeds = mutableListOf<BedResponse>()
    private val displayBeds = mutableListOf<BedResponse>()

    private val alarmCache = mutableMapOf<String, MutableMap<String, Pair<Int, Long>>>()
    private val alarmIndexMap = mutableMapOf<String, Int>()

    private val handler = Handler(Looper.getMainLooper())

    //  HOLD LOGIC
    private val lastAlarmTimeMap = mutableMapOf<String, Long>()
    private val lastAlarmCodeMap = mutableMapOf<String, Int>()
    private val alarmHoldDuration = 2000L

    init {
        startAlarmRotation()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.cardview_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = displayBeds[position]

        bindFullData(holder, item)
    }

    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int,
        payloads: MutableList<Any>
    ) {
        if (payloads.isNotEmpty()) {
            updateAlarmOnly(holder, displayBeds[position])
            return
        }
        super.onBindViewHolder(holder, position, payloads)
    }

    private fun bindFullData(holder: ViewHolder, item: BedResponse) {

        val alarms = item.alarms
        val bedNo = item.bedNo
        val currentTime = System.currentTimeMillis()

        holder.tvAlarm.clearAnimation()
        holder.Hr.clearAnimation()
        holder.tvAlarm.visibility = View.GONE

        // Alarm cache
        if (!alarmCache.containsKey(bedNo)) {
            alarmCache[bedNo] = mutableMapOf()
            alarmIndexMap[bedNo] = 0
        }

        alarms.forEach { (key, value) ->
            if (value != null) {
                alarmCache[bedNo]?.put(key, Pair(value, currentTime))
            }
        }

        val expiry = 10000

        val activeAlarms = alarmCache[bedNo]?.filter {
            currentTime - it.value.second <= expiry
        } ?: emptyMap()

        if (activeAlarms.isNotEmpty()) {
            val alarmList = activeAlarms.toList()
            val index = alarmIndexMap[bedNo] ?: 0

            val safeIndex = index % alarmList.size
            val (name, pair) = alarmList[safeIndex]

            holder.tvAlarm.visibility = View.VISIBLE
            holder.tvAlarm.text = name.replace("_", " ").uppercase()
            setAlarmColor(holder.tvAlarm, pair.first)

            alarmIndexMap[bedNo] = safeIndex + 1
        }

        holder.BedNo.text = item.bedNo
        holder.Name.text = item.patientName
        holder.Age.text = item.age
        holder.Gender.text = item.gender
        holder.Hr.text = item.hr
        holder.Spo2.text = item.spo2
        holder.RR.text = item.rr
        holder.Sys.text = item.sys
        holder.Dia.text = item.dia
        holder.Mean.text = item.mean

        // HR logic
        val hrLow = alarms["hr_low"]
        val hrHigh = alarms["hr_high"]

        if (hrLow != null) {
            lastAlarmTimeMap[bedNo] = currentTime
            lastAlarmCodeMap[bedNo] = hrLow
        } else if (hrHigh != null) {
            lastAlarmTimeMap[bedNo] = currentTime
            lastAlarmCodeMap[bedNo] = hrHigh
        }

        updateAlarmOnly(holder, item)

        holder.mainCardView.setOnClickListener { onItemClick(item) }
    }

    private fun updateAlarmOnly(holder: ViewHolder, item: BedResponse) {

        val bedNo = item.bedNo
        val currentTime = System.currentTimeMillis()

        val lastTime = lastAlarmTimeMap[bedNo] ?: 0
        val lastCode = lastAlarmCodeMap[bedNo]

        if (currentTime - lastTime <= alarmHoldDuration && lastCode != null) {
            stopBlinking(holder.Hr)
            setAlarmColor(holder.Hr, lastCode)
            startBlinking(holder.Hr)
        } else {
            stopBlinking(holder.Hr)
            holder.Hr.setBackgroundColor(Color.TRANSPARENT)
            holder.Hr.setTextColor(Color.parseColor("#005904"))
        }
    }

    override fun getItemCount(): Int = displayBeds.size

    private fun setAlarmColor(view: TextView, code: Int?) {
        when (code) {
            0 -> {
                view.setBackgroundColor(Color.TRANSPARENT)
                view.setTextColor(Color.BLACK)
            }
            1 -> {
                view.setBackgroundColor(Color.parseColor("#03dbfc"))
                view.setTextColor(Color.BLACK)
            }
            2 -> {
                view.setBackgroundColor(Color.YELLOW)
                view.setTextColor(Color.BLACK)
            }
            3 -> {
                view.setBackgroundColor(Color.RED)
                view.setTextColor(Color.WHITE)
            }
        }
    }

    private fun startBlinking(view: TextView) {
        view.clearAnimation()

        val anim = AlphaAnimation(0.5f, 1.0f)
        anim.duration = 800
        anim.repeatMode = Animation.REVERSE
        anim.repeatCount = Animation.INFINITE

        view.startAnimation(anim)
    }

    private fun stopBlinking(view: TextView) {
        view.clearAnimation()
    }

    //  ONLY PARTIAL UPDATE
    private fun startAlarmRotation() {
        handler.postDelayed(object : Runnable {
            override fun run() {

                displayBeds.indices.forEach {
                    notifyItemChanged(it, "ALARM_UPDATE")
                }

                handler.postDelayed(this, 2000)
            }
        }, 2000)
    }

    fun updateOrAddBed(newBed: BedResponse) {
        val index = allBeds.indexOfFirst { it.bedNo == newBed.bedNo }

        if (index == -1) {
            allBeds.add(newBed)
        } else {
            if (allBeds[index] == newBed) return
            allBeds[index] = newBed
        }

        allBeds.sortBy { it.bedNo.toIntOrNull() ?: Int.MAX_VALUE }

        displayBeds.clear()
        displayBeds.addAll(allBeds)
        notifyDataSetChanged()
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val BedNo: TextView = itemView.findViewById(R.id.bedNo)
        val tvAlarm: TextView = itemView.findViewById(R.id.tvAlarm)
        val Name: TextView = itemView.findViewById(R.id.name)
        val Age: TextView = itemView.findViewById(R.id.age)
        val Gender: TextView = itemView.findViewById(R.id.gender)
        val Hr: TextView = itemView.findViewById(R.id.tvHRValue)
        val Spo2: TextView = itemView.findViewById(R.id.Spo2val)
        val RR: TextView = itemView.findViewById(R.id.PRVal)
        val Sys : TextView = itemView.findViewById(R.id.NIBPsys)
        val Dia : TextView = itemView.findViewById(R.id.NIBPdia)
        val Mean : TextView = itemView.findViewById(R.id.NIBPmean)
        val mainCardView: CardView = itemView.findViewById(R.id.maincradview)
    }
}