package com.example.ecgapp

import android.opengl.GLSurfaceView
import android.opengl.GLU
import android.util.Log
import java.util.concurrent.ConcurrentLinkedQueue
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/*
class GLRenderer1 : GLSurfaceView.Renderer {

    private val line = Line1()
    private val queue = ConcurrentLinkedQueue<Float>()

    // ----  timebase ----
    private val sampleIntervalNs = 4_000_000L   // 4ms = 250Hz
    private var lastSampleTime = 0L

    fun addPoint(value: Float) {
        queue.offer(value)
        Log.d("BUFFER", "Queue size = ${queue}")

    }


    override fun onSurfaceCreated(gl: GL10, config: EGLConfig) {
        lastSampleTime = System.nanoTime()   //  MUST

        gl.glClearColor(0f, 0f, 0f, 1f)
        gl.glEnable(GL10.GL_LINE_SMOOTH)
        gl.glHint(GL10.GL_LINE_SMOOTH_HINT, GL10.GL_NICEST)
    }


    override fun onSurfaceChanged(gl: GL10, width: Int, height: Int) {
        gl.glViewport(0, 0, width, height)
        gl.glMatrixMode(GL10.GL_PROJECTION)
        gl.glLoadIdentity()
        GLU.gluOrtho2D(gl, -1f, 1f, -1f, 1f)
        gl.glMatrixMode(GL10.GL_MODELVIEW)
        gl.glLoadIdentity()
    }

    *//*override fun onDrawFrame(gl: GL10) {
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT)

        val now = System.nanoTime()

        // ----  pacing loop ----
        while (now - lastSampleTime >= sampleIntervalNs) {
            queue.poll()?.let {
                line.addSample(it)
            }
            lastSampleTime += sampleIntervalNs
        }

        line.draw(gl)
    }*//*

    override fun onDrawFrame(gl: GL10) {
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT)

        val now = System.nanoTime()

        while (now - lastSampleTime >= sampleIntervalNs) {

            val value = queue.poll()

            if (value == null) {

                break
            }
            line.addSample(value)
            lastSampleTime += sampleIntervalNs
        }

        line.draw(gl)
    }

}*/


//new

class GLRenderer1 : GLSurfaceView.Renderer {

    private val line = Line1()
    private val queue = ConcurrentLinkedQueue<Float>()

    // ---- ECG timebase ----
    private val sampleIntervalNs = 4_000_000L   // 250 Hz
    private var lastSampleTime = 0L

    private var started = false   //  VERY IMPORTANT

    fun addPoint(value: Float) {
        queue.offer(value)
    }

    override fun onSurfaceCreated(gl: GL10, config: EGLConfig) {
        lastSampleTime = System.nanoTime()

        gl.glClearColor(0f, 0f, 0f, 1f)
        gl.glEnable(GL10.GL_LINE_SMOOTH)
        gl.glHint(GL10.GL_LINE_SMOOTH_HINT, GL10.GL_NICEST)
    }

    override fun onSurfaceChanged(gl: GL10, width: Int, height: Int) {
        gl.glViewport(0, 0, width, height)

        gl.glMatrixMode(GL10.GL_PROJECTION)
        gl.glLoadIdentity()
        GLU.gluOrtho2D(gl, -1f, 1f, -1f, 1f)

        gl.glMatrixMode(GL10.GL_MODELVIEW)
        gl.glLoadIdentity()
    }

    override fun onDrawFrame(gl: GL10) {
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT)

        val now = System.nanoTime()

        while (now - lastSampleTime >= sampleIntervalNs) {

            val value = queue.poll() ?: break

            //  WARM-UP PHASE (NO DRAWING, NO TIME ADVANCE)
            if (!started) {

                line.collectWarmup(value)

                if (line.isWarmupDone()) {
                    line.reset()
                    started = true
                    lastSampleTime = now   //  time sync
                    Log.d("ECG", "Warmup done → ECG started clean")
                }

                continue
            }

            //  REAL ECG DRAWING
            line.addSample(value)
            lastSampleTime += sampleIntervalNs
        }

        line.draw(gl)
    }
}
