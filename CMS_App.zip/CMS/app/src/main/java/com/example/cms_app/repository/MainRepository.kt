package com.example.cms_app.repository

import com.example.cms_app.data.model.LoginResponse
import com.example.cms_app.network.Loginrequest
import kotlinx.coroutines.delay
import com.example.cms_app.network.ApiService
import retrofit2.Response
import javax.inject.Inject

class MainRepository @Inject constructor(private val api : ApiService) {

    suspend fun login(userId: String , password: String): Response<LoginResponse> {
        delay(2000)
        return api.login(Loginrequest(userId, password))
    }
}
