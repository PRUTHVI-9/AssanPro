package com.example.cms_app.view

import android.app.Application
import com.example.cms_app.utilis.AppLifecycleTracker
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MyApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        AppLifecycleTracker.init()
    }
}