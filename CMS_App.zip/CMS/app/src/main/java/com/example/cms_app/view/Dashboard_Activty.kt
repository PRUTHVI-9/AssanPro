package com.example.cms_app.view

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.cms_app.Helper.MqttManager
import com.example.cms_app.R
import com.example.cms_app.databinding.ActivityDashboardActivtyBinding

class Dashboard_Activty : AppCompatActivity() {
    lateinit var binding: ActivityDashboardActivtyBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_dashboard_activty)

        binding = ActivityDashboardActivtyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sharedpref = getSharedPreferences("Sharedpref",MODE_PRIVATE)
        val userId = sharedpref.getString("empId","")?: ""

        // val topics = intent.getStringArrayListExtra("topics")
        // val userId = intent.getStringExtra("userId")
        // val password = intent.getStringExtra("password")
        //Log.e("dastopic", "onCreate: $topics", )

        binding.drname.setText(userId)

        binding.totalPatient.setOnClickListener {
            val intent = Intent(this, MyBedActivity::class.java)
            // intent.putStringArrayListExtra("topics", topics)
            // Log.d("aaa", "onCreate: $topics")
             intent.putExtra("userId", userId)
            // intent.putExtra("password", password)
            startActivity(intent)
            finish()
        }

        binding.todayPatient.setOnClickListener {
            val intent = Intent(this, MyBedActivity::class.java)
            //  intent.putStringArrayListExtra("topics",topics)
            startActivity(intent)
            finish()
        }

        binding.logout.setOnClickListener {
            val sharedPref = getSharedPreferences("Sharedpref", MODE_PRIVATE)
            with(sharedPref.edit()) {
                clear()
                apply()
            }

            MqttManager.disconnect()
            val intent = Intent(this, Login_Activity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }
}