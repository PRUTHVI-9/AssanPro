package com.example.cms_app.data


data class AlarmItem(

    val image : Int,
    val title: String,
    val unit: String,

    var lowValue: Int,
    var highValue: Int,

    val minRange: Int,
    val maxRange: Int,

    val color: String
)