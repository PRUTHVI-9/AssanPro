package com.example.cms_app

import android.opengl.GLSurfaceView
import android.util.Log
import java.util.concurrent.ConcurrentLinkedQueue
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class GLRendererCombined : GLSurfaceView.Renderer {

    // ================= RATES =================
    // private val ECG_RATE = 250f
    private val SPO2_RATE = 100f
    private val MASTER_RATE = 250f

    private val SWEEP_SPEED = 256f   // px/sec

    private var screenWidth = 0
    private var screenHeight = 0

    private var pixelPerSample = 0f
    private var samplesPerScreen = 0

    // -------- MASTER CLOCK --------
    private val sampleIntervalNs =
        (1_000_000_000L / MASTER_RATE).toLong()

    private var lastSampleTime = System.nanoTime()
    private val MAX_SAMPLES_PER_FRAME = 4

    // -------- DATA QUEUES --------
    private val ecgQueue = ConcurrentLinkedQueue<Float>()
    private val spo2Queue = ConcurrentLinkedQueue<Float>()

    private val ecgLine = CombineLinewave()
    private val spo2Line = CombineLinewave()

    private var lastEcg = 0f

    // -------- SPO2 INTERPOLATION (FLOAT BASED) --------
    private var lastSpo2 = 0f
    private var nextSpo2 = 0f
    private var spo2Accumulator = 0f
    private val spo2StepSize = SPO2_RATE / MASTER_RATE   // 0.4

    fun addECG(v: Float) = ecgQueue.offer(v)
    fun addECGII(v: Float) = ecgQueue.offer(v)
    fun addSPO2(v: Float) = spo2Queue.offer(v)

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        gl?.glClearColor(0f, 0f, 0f, 1f)        //black
        lastSampleTime = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {

        gl?.glViewport(0, 0, width, height)

        screenWidth = width
        screenHeight = height

        pixelPerSample = SWEEP_SPEED / MASTER_RATE         //256 / 250 ≈ 1.024 pixel

        val visibleSeconds = screenWidth / SWEEP_SPEED      //
        samplesPerScreen = (visibleSeconds * MASTER_RATE).toInt()   //samples value

        ecgLine.initialize(
            samplesPerScreen,
            true,
            pixelPerSample,
            screenWidth,
            CombineLinewave.Type.ECG
        )

        spo2Line.initialize(
            samplesPerScreen,
            false,
            pixelPerSample,
            screenWidth,
            CombineLinewave.Type.SPO2
        )
    }

    override fun onDrawFrame(gl: GL10?) {

        gl ?: return
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT)

        val now = System.nanoTime()
        val elapsedNs = now - lastSampleTime

        val samplesToProcess =
            (elapsedNs / sampleIntervalNs)
                .toInt()
                .coerceAtMost(MAX_SAMPLES_PER_FRAME)

        if (samplesToProcess > 0) {

            /*repeat(samplesToProcess) {

                val ecgSample = ecgQueue.poll() ?: lastEcg

                lastEcg = ecgSample
                Log.d("QUEUE", "ECG size = ${ecgQueue.size}")
                Log.d("QUEUE", "spo2 size = ${spo2Queue.size}")

                val spo2Sample = getInterpolatedSpo2()

                ecgLine.addSample(ecgSample)
                spo2Line.addSample(spo2Sample)
            }*/

            repeat(samplesToProcess) {

                val ecgSample = ecgQueue.poll()

                val finalSample = if (ecgSample != null) {
                    lastEcg = ecgSample
                    ecgSample
                } else {
                    lastEcg *= 0.98f
                    lastEcg
                }
                ecgLine.addSample(finalSample)
                val spo2Sample = getInterpolatedSpo2()
                spo2Line.addSample(spo2Sample)
//                Log.d("QUEUE", "ECG size = ${ecgQueue.size}")
//                Log.d("QUEUE", "spo2 size = ${spo2Queue.size}")
            }

            lastSampleTime += samplesToProcess * sampleIntervalNs
        }

        // Draw ECG
        gl.glColor4f(0f, 1f, 0f, 1f)
        ecgLine.draw(gl)

        // Draw SPO2
        gl.glColor4f(0f, 1f, 1f, 1f)
        spo2Line.draw(gl)
    }

    // -------- SMOOTH FLOAT INTERPOLATION --------
    private fun getInterpolatedSpo2(): Float {

        spo2Accumulator += spo2StepSize

        if (spo2Accumulator >= 1f) {
            spo2Accumulator -= 1f
            lastSpo2 = nextSpo2
            nextSpo2 = spo2Queue.poll() ?: lastSpo2
        }

        val interpolated =
            lastSpo2 + (nextSpo2 - lastSpo2) * spo2Accumulator

        return interpolated
    }

}