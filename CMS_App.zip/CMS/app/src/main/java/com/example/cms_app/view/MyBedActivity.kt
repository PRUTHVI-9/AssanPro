package com.example.cms_app.view

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cms_app.Adpter.MyBedsAdapter
import com.example.cms_app.data.BedResponse
import com.example.cms_app.data.model.MqttViewModel
import com.example.cms_app.databinding.ActivityMyBedBinding
import com.example.cms_app.view.Fragment.Combine_Main_Activity
import org.json.JSONObject


class MyBedActivity : AppCompatActivity() {

    lateinit var binding: ActivityMyBedBinding
    private lateinit var adpter: MyBedsAdapter
    private lateinit var mqttViewModel: MqttViewModel
    private var selectedTopic : String = ""
    private val lastVitalsMap = mutableMapOf<String, Triple<String, String, String>>()
    private var isFirstdata = true
    private val lastAlarmMap = mutableMapOf<String, Map<String, Int?>>()
    private val handeler = Handler(Looper.getMainLooper())
    private val timeoutMills = 1000L
    // private val lastUpdateTime = mutableListOf<String, Long>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMyBedBinding.inflate(layoutInflater)
        setContentView(binding.root)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE}

        if (!isInternetAvailable()){
            Toast.makeText(this, "No Internet Connection", Toast.LENGTH_SHORT).show()
            return
        }


        mqttViewModel = ViewModelProvider(this)[MqttViewModel::class.java]

        adpter = MyBedsAdapter { bed ->
//            val intent = Intent(this, GLSurfaceCombineActivity::class.java)
            val intent = Intent(this, Combine_Main_Activity::class.java)
            intent.putExtra("patient_name", bed.patientName)
            intent.putExtra("Topic", bed.topic)
            intent.putExtra("bedNo",bed.bedNo)
            startActivity(intent)
        }

        binding.listView.layoutManager = LinearLayoutManager(this)
        binding.listView.adapter = adpter
        handleBackPress()
        BedListobserveMqtt()   //
//        monitorNetwork()
//        Connection()
        //observeConnection()
    }


    private fun BedListobserveMqtt() {
        MqttViewModel.mqttData.observe(this) { (topics, msg) ->
            Log.e("MQTT_UI", "Topic: $topics")

//            handeler.removeCallbacks(clearRunnable)
//            handeler.postDelayed(clearRunnable,timeoutMills)

            /*if (isFirstdata){
                adpter.clearAll()
                lastVitalsMap.clear()
                isFirstdata = false
            }*/
            if (topics.endsWith("vitals") || topics.endsWith("full")) {
                parsePatientList(topics, msg)
            }
        }
    }


    private fun parsePatientList(topic: String, json: String) {
        try {

            val baseTopic = topic.substringBeforeLast("/")
            val fullTopic = "$baseTopic/full"

            val root = JSONObject(json)
            Log.e("jsonbedlist", "$root")

            val bedNo = root.optString("bed_no", "--")

            val isFullTopic = topic.endsWith("full")

            val alarmsMap = mutableMapOf<String, Int?>()

            if (isFullTopic) {
                val alarmsObj = root.optJSONObject("alarms")
                Log.e("alarmsObj", "Alarms Object: $alarmsObj")
                if (alarmsObj != null) {
                    val keys = alarmsObj.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        val value = if (alarmsObj.isNull(key)) null else alarmsObj.optInt(key)
                        Log.e("MQTT_DEBUG", "Alarm -> $key = $value")

                        alarmsMap[key] = value
                    }
                }
                lastAlarmMap[bedNo] = alarmsMap
            }
            val finalAlarms = lastAlarmMap[bedNo] ?: emptyMap()

            //  PATIENT DATA

            val patient = root.optJSONObject("patient")
            val name = patient?.optString("name") ?: "--"

            val age = patient?.optInt("age", -1)
                ?.takeIf { it > 0 }
                ?.toString() ?: "--"

            val gender = patient?.optString("gender") ?: "--"

            //  VITALS

            val hrNew = root.optInt("hr", -1)
                .takeIf { it > 0 }
                ?.toString()

            val spo2New = root.optInt("spo2", -1)
                .takeIf { it > 0 }
                ?.toString()

            val resp = root.optJSONObject("resp")

            val rrNew = resp?.optInt("rr", -1)
                ?.takeIf { it > 0 }
                ?.toString()

            val nibp = root.optJSONObject("nibp")
            val sysNew = nibp?.optInt("sys",-1)?.takeIf{it > 0}?.toString()
            val diaNew = nibp?.optInt("dia",-1)?.takeIf { it > 0 }?.toString()
            val meanNew = nibp?.optInt("mean",-1)?.takeIf { it > 0 }?.toString()


            //  LAST VITALS CACHE

            val last = lastVitalsMap[bedNo]

            val hr = hrNew ?: last?.first ?: "--"
            val spo2Val = spo2New ?: last?.second ?: "--"
            val rr = rrNew ?: last?.third ?: "--"
            val sys = sysNew ?: "--"
            val dia = diaNew ?: "--"
            val mean = meanNew ?: "--"

            if (hrNew != null || spo2New != null || rrNew != null) {
                lastVitalsMap[bedNo] = Triple(hr, spo2Val, rr)
            }

            val bed = BedResponse(
                patientName = name,
                bedNo = bedNo,
                age = age,
                gender = gender,
                hr = hr,
                spo2 = spo2Val,
                rr = rr,
                sys = sys,
                dia = dia,
                mean = mean,
                topic = fullTopic,
                alarms = finalAlarms
            )

            runOnUiThread {
                adpter.updateOrAddBed(bed)
            }

        } catch (e: Exception) {
            Log.e("BED_JSON", e.toString())
        }
    }


    private fun handleBackPress() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val intent = Intent(this@MyBedActivity, Dashboard_Activty::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
                startActivity(intent)
                finish()
            } } )
    }
    private fun observeConnection() {
        MqttViewModel.connectionStatus.observe(this) { isConnected ->

            if (!isConnected) {
                Log.e("MQTT", "Disconnected → clear list")

                //   adpter.clearAll()
                lastVitalsMap.clear()
            }
        }
    }
    fun isInternetAvailable(): Boolean{
        val connectivityManager =  getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network)?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)

    }

    private fun Connection() {
        MqttViewModel.connectionStatus.observe(this) { isConnected ->

            if (!isConnected) {
                Log.e("MQTT", "Disconnected → clear list")

                runOnUiThread {
                    //   adpter.clearAll()
                    lastVitalsMap.clear()
                    lastAlarmMap.clear()
                }

            } else {
                Log.e("MQTT", "Connected → waiting for data")
            }
        }
    }
    private fun monitorNetwork() {

        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        val callback = object : ConnectivityManager.NetworkCallback() {

            override fun onLost(network: Network) {
                runOnUiThread {
                    Log.e("NETWORK", "Lost")

                    //   adpter.clearAll()
                    lastVitalsMap.clear()
                    lastAlarmMap.clear()

                    MqttViewModel.connectionStatus.postValue(false)
                }
            }

            override fun onAvailable(network: Network) {
                runOnUiThread {
                    Log.e("NETWORK", "Available")

                    mqttViewModel.reconnect()
                }
            }
        }

        cm.registerDefaultNetworkCallback(callback)
    }

    override fun onDestroy() {
        super.onDestroy()
        // handeler.removeCallbacks { clearRunnable }
    }
}
