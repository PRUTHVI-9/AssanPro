package com.example.cms_app

import android.opengl.GLSurfaceView
import android.opengl.GLU
import android.util.Log
import java.util.concurrent.ConcurrentLinkedQueue
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class GLRenderer3 : GLSurfaceView.Renderer {

    private val line = Line3()
    private val queue = ConcurrentLinkedQueue<Float>()

    // ---- ECG master clock ----
    private val sampleIntervalNs = 4_000_000L   // 250 Hz
    private var lastSampleTime = 0L

    private var started = false

    // ---- SpO₂ interpolation ----
    private val RR_RATE = 90f
    private val ECG_RATE = 250f
    private val HOLD_COUNT = (ECG_RATE / RR_RATE).toInt()

    private var lastValue: Float? = null
    private var targetValue: Float? = null
    private var interpStep = 0f


    private var holdCounter = 0
    private var currentValue: Float? = null


    fun addPoint(value: Float) {
        Log.d("RR", "value = $value")
        queue.offer(value)
    }


    override fun onSurfaceCreated(gl: GL10, config: EGLConfig) {
        lastSampleTime = System.nanoTime()

        gl.glClearColor(0f, 0f, 0f, 1f)
        gl.glEnable(GL10.GL_LINE_SMOOTH)
        gl.glHint(GL10.GL_LINE_SMOOTH_HINT, GL10.GL_NICEST)
    }

    override fun onSurfaceChanged(gl: GL10, width: Int, height: Int) {
        gl.glViewport(0, 0, width, height)

        gl.glMatrixMode(GL10.GL_PROJECTION)
        gl.glLoadIdentity()
        GLU.gluOrtho2D(gl, -1f, 1f, -1f, 1f)

        gl.glMatrixMode(GL10.GL_MODELVIEW)
        gl.glLoadIdentity()
    }

    override fun onDrawFrame(gl: GL10) {
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT)

        val now = System.nanoTime()

        while (now - lastSampleTime >= sampleIntervalNs) {

            // ---- wait for first RR value ----
            if (currentValue == null) {
                queue.poll()?.let {
                    currentValue = it
                    holdCounter = HOLD_COUNT
                }
                lastSampleTime += sampleIntervalNs
                continue
            }

            // ---- fetch new RR only when hold expires ----
            if (holdCounter <= 0) {
                queue.poll()?.let {
                    currentValue = it
                    holdCounter = HOLD_COUNT
                }
            }

            // ---- ALWAYS draw ----
            line.addSample(currentValue!!)
            holdCounter--

            lastSampleTime += sampleIntervalNs
        }

        line.draw(gl)
    }

}
