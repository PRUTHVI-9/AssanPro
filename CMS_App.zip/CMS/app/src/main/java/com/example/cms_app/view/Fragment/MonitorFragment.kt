package com.example.cms_app.view.Fragment

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.cms_app.R
import com.example.cms_app.data.model.MqttViewModel
import com.example.cms_app.databinding.FragmentMonitorBinding
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.graphics.Color
import com.example.cms_app.Helper.MqttManager
class MonitorFragment : Fragment(R.layout.fragment_monitor) {

    private var _binding: FragmentMonitorBinding? = null
    private val binding get() = _binding!!

    private lateinit var mqttViewModel: MqttViewModel

    private var selectedTopic: String = ""

    private lateinit var clockHandler: Handler
    private lateinit var clockRunnable: Runnable

    // Alarm
    private val alarmCache = mutableMapOf<String, Pair<Int, Long>>()
    private var alarmIndex = 0
    private val alarmHandler = Handler(Looper.getMainLooper())

    private var lastAlarmTime: Long = 0
    private val alarmHoldDuration = 2000L
    private var lastAlarmCode: Int? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        _binding = FragmentMonitorBinding.bind(view)

        mqttViewModel =
            ViewModelProvider(requireActivity())[MqttViewModel::class.java]

        selectedTopic =
            requireActivity().intent.getStringExtra("Topic") ?: ""

        val patient =
            requireActivity().intent.getStringExtra("patient_name") ?: ""

        binding.textPatientName.text = patient

        if (!isInternetAvailable()) {
            Toast.makeText(
                requireContext(),
                "No Network Available",
                Toast.LENGTH_SHORT
            ).show()
        }

        /*//two- way communcation
        val doctorName = "DoctorLele"

        MqttManager.disconnect()

        val topics = mutableListOf<String>()
        topics.add("ICU1/$doctorName/Bed2/desktopToMobile")

        MqttManager.connect(
            userId = "Lele",
            password = "Lele123",
            topics = topics
        ) { topic, message ->

            Log.d("twoway", "RECEIVED → $topic : $message")

            if (topic == "ICU1/$doctorName/Bed2/desktopToMobile") {

                requireActivity().runOnUiThread {
                    binding.text1.text = message
                }
            }
        }

        binding.text1.setOnClickListener {

            val sendTopic = "ICU1/$doctorName/Bed2/mobileToDesktop"

            MqttManager.publish(sendTopic, "Hii")

            Log.d("twoway", "Message Sent")
        }*/


        startClock()
        startAlarmRotation()
        observeMqtt()
    }

    private fun observeMqtt() {

        MqttViewModel.mqttData.observe(viewLifecycleOwner) { (topic, msg) ->

            val baseTopic = selectedTopic.substringBeforeLast("/")

            if (!topic.startsWith(baseTopic)) return@observe

            if (topic.endsWith("full")) {

                if (topic != selectedTopic) return@observe

                handleFullJson(msg)
            }
        }
    }

    private fun handleFullJson(msg: String) {

        try {

            val root = JSONObject(msg)

            val alarmsObj = root.optJSONObject("alarms")

            val hr = root.optInt("hr", -1)

            val hrLow =
                if (alarmsObj?.isNull("hr_low") == false)
                    alarmsObj.optInt("hr_low")
                else null

            val hrHigh =
                if (alarmsObj?.isNull("hr_high") == false)
                    alarmsObj.optInt("hr_high")
                else null

            if (hr > 0) {
                binding.ecgval.text = hr.toString()
            }

            val currentTime = System.currentTimeMillis()

            if (hrLow != null) {

                lastAlarmTime = currentTime
                lastAlarmCode = hrLow

            } else if (hrHigh != null) {

                lastAlarmTime = currentTime
                lastAlarmCode = hrHigh
            }

            if (
                currentTime - lastAlarmTime <= alarmHoldDuration &&
                lastAlarmCode != null
            ) {

                stopBlinking(binding.ecgval)

                setAlarmColor(binding.ecgval, lastAlarmCode)

                startBlinkingSafe(binding.ecgval)

            } else {

                stopBlinking(binding.ecgval)

                binding.ecgval.setBackgroundColor(Color.TRANSPARENT)

                binding.ecgval.setTextColor(Color.GREEN)
            }

            // SPO2
            val spo2Val =
                root.optJSONObject("spo2")
                    ?.optInt("value", -1) ?: -1

            if (spo2Val > 0) {
                binding.spo2val.text = spo2Val.toString()
            }

            // RESP
            val rr =
                root.optJSONObject("resp")
                    ?.optInt("rr", -1) ?: -1

            if (rr > 0) {
                binding.respval.text = rr.toString()
            }

            // NIBP
            val nibp = root.optJSONObject("nibp")

            val sys = nibp?.optInt("sys", -1) ?: -1
            val dia = nibp?.optInt("dia", -1) ?: -1
            val mean = nibp?.optInt("mean", -1) ?: -1

            if (sys > 0) {
                binding.NIBPSya.text = "$sys"
            }

            if (dia > 0) {
                binding.NIBPDia.text = "$dia"
            }
            if (mean > 0) {
                binding.NIBPmean.text = "$mean"
            }

            // Alarm Cache
            alarmsObj?.keys()?.forEach { key ->

                val value = alarmsObj.optInt(key, -1)

                if (value != -1) {

                    alarmCache[key] =
                        Pair(value, currentTime)
                }
            }

            handleECG(root)

            handleSPO2(root)

        } catch (e: Exception) {

            Log.e("FULL_JSON_ERROR", e.toString())
        }
    }

    private fun handleECG(root: JSONObject) {

        val ecg = root.optJSONObject("ecg") ?: return

        val wf = ecg.optJSONObject("waveform") ?: return

        val leadI = wf.optJSONArray("I") ?: return

        for (i in 0 until leadI.length()) {

            val value = leadI.getDouble(i).toFloat()
            Log.e("ECG", "handleECG: $value", )

            binding.glCombined.queueEvent {

                binding.glCombined.addECG(value)
            }
        }
    }

    private fun handleSPO2(root: JSONObject) {

        val spo2 = root.optJSONObject("spo2") ?: return

        val wf = spo2.optJSONArray("waveform") ?: return

        if (wf.length() < 10) return

        for (i in 0 until wf.length()) {

            val value = wf.getDouble(i).toFloat()
            Log.e("SPO2", "handleSPO2: $value", )

            binding.glCombined.queueEvent {
                binding.glCombined.addSPO2(value)
            }
        }
    }

    private fun startAlarmRotation() {

        alarmHandler.postDelayed(object : Runnable {

            override fun run() {

                val currentTime = System.currentTimeMillis()

                val expiry = 5000

                val activeAlarms = alarmCache.filter {

                    currentTime - it.value.second <= expiry
                }

                if (activeAlarms.isEmpty()) {

                    binding.tvAlarm.visibility = View.GONE

                } else {

                    binding.tvAlarm.visibility = View.VISIBLE

                    val alarmList = activeAlarms.toList()

                    val safeIndex =
                        alarmIndex % alarmList.size

                    val (name, pair) =
                        alarmList[safeIndex]

                    binding.tvAlarm.text =
                        name.replace("_", " ").uppercase()

                    setAlarmColor(binding.tvAlarm, pair.first)

                    alarmIndex = safeIndex + 1
                }

                alarmHandler.postDelayed(this, 1000)
            }

        }, 1000)
    }

    private fun setAlarmColor(
        view: TextView,
        code: Int?
    ) {

        when (code) {

            0 -> {
                view.setBackgroundColor(Color.TRANSPARENT)
                view.setTextColor(Color.WHITE)
            }

            1 -> {
                view.setBackgroundColor(
                    Color.parseColor("#03dbfc")
                )
                view.setTextColor(Color.BLACK)
            }

            2 -> {
                view.setBackgroundColor(Color.YELLOW)
                view.setTextColor(Color.BLACK)
            }

            3 -> {
                view.setBackgroundColor(Color.RED)
                view.setTextColor(Color.WHITE)
            }

            else -> {
                view.setBackgroundColor(Color.TRANSPARENT)
                view.setTextColor(Color.GREEN)
            }
        }
    }

    private fun startBlinkingSafe(view: TextView) {

        view.clearAnimation()

        val anim = AlphaAnimation(0.5f, 1.0f)

        anim.duration = 800
        anim.repeatMode = Animation.REVERSE
        anim.repeatCount = Animation.INFINITE

        view.startAnimation(anim)
    }

    private fun stopBlinking(view: TextView) {

        view.clearAnimation()
    }

    private fun startClock() {

        clockHandler = Handler(Looper.getMainLooper())

        clockRunnable = object : Runnable {

            override fun run() {

                val currentTime =
                    SimpleDateFormat(
                        "HH:mm:ss",
                        Locale.getDefault()
                    ).format(Date())

                binding.time.text = currentTime

                clockHandler.postDelayed(this, 1000)
            }
        }

        clockHandler.post(clockRunnable)
    }

    private fun isInternetAvailable(): Boolean {

        val connectivityManager =
            requireContext().getSystemService(
                Context.CONNECTIVITY_SERVICE
            ) as ConnectivityManager

        val network =
            connectivityManager.activeNetwork ?: return false

        val capabilities =
            connectivityManager.getNetworkCapabilities(network)
                ?: return false

        return capabilities.hasCapability(
            NetworkCapabilities.NET_CAPABILITY_INTERNET
        )
    }

    override fun onResume() {
        super.onResume()
        binding.glCombined.onResume()
    }

    override fun onPause() {
        super.onPause()
        binding.glCombined.onPause()
    }

    override fun onDestroyView() {
        super.onDestroyView()

        clockHandler.removeCallbacks(clockRunnable)

        alarmHandler.removeCallbacksAndMessages(null)

        _binding = null
    }
}