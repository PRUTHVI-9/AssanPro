package com.example.cms_app.data

data class BedResponse(
    val bedNo: String,
    val patientName: String,
    val age: String,
    val gender: String,
    val hr: String,
    val spo2: String,
    val rr: String,
    val sys : String,
    val dia : String,
    val mean : String,
    val topic: String,
    val alarms: Map<String, Int?>
)

