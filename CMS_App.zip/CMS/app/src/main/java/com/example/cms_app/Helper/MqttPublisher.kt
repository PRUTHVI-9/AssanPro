package com.example.cms_app.Helper

import android.util.Log
import com.hivemq.client.mqtt.MqttClient
import com.hivemq.client.mqtt.datatypes.MqttQos
import com.hivemq.client.mqtt.mqtt3.Mqtt3AsyncClient
import java.nio.charset.StandardCharsets


class MqttPublisher(
    private val brokerHost: String = "192.168.100.45",
    private val brokerPort: Int = 1883
) {
    private val clientId = "Publisher-" + System.currentTimeMillis()
    private val client: Mqtt3AsyncClient = MqttClient.builder()
        .identifier(clientId)
        .serverHost(brokerHost)
        .serverPort(brokerPort)
        .useMqttVersion3()
        .buildAsync()

    fun connect(onConnected: (() -> Unit)? = null) {
        client.connect().whenComplete { _, throwable ->
            if (throwable == null) {
                Log.i("MQTT", "Publisher connected")
                onConnected?.invoke()
            } else {
                Log.e("MQTT", "Publisher connection failed: ${throwable.message}", throwable)
            }
        }
    }

    fun publish(topic: String, message: String) {
        client.publishWith()
            .topic(topic)
            .payload(message.toByteArray(StandardCharsets.UTF_8))
            .qos(MqttQos.AT_LEAST_ONCE)
            .send()
            .whenComplete { _, throwable ->
                if (throwable == null)
                    Log.i("MQTT", "Sent → [$topic]: $message")
                else
                    Log.e("MQTT", "Publish failed: ${throwable.message}")
            }
    }

    fun disconnect() {
        client.disconnect()
    }
}
