package com.example.cms_app

import android.opengl.GLSurfaceView
import android.opengl.GLU
import android.util.Log
import java.util.concurrent.ConcurrentLinkedQueue
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
/*

class GLRenderer2 : GLSurfaceView.Renderer {

    private val line = Line2()
    private val queue = ConcurrentLinkedQueue<Float>()

    // ----  timebase ----
    private val sampleIntervalNs =  4_000_000L    // 4ms = 250Hz
    private var lastSampleTime = 0L
    private var lastSpo2Value: Float? = null
    private val interpSteps = 2  //
    private var interpIndex = 0


    fun addPoint(value: Float) {
        queue.offer(value)
    }

    override fun onSurfaceCreated(gl: GL10, config: EGLConfig) {
        gl.glClearColor(0f, 0f, 0f, 1f)
        gl.glEnable(GL10.GL_LINE_SMOOTH)
        gl.glHint(GL10.GL_LINE_SMOOTH_HINT, GL10.GL_NICEST)
    }

    override fun onSurfaceChanged(gl: GL10, width: Int, height: Int) {
        gl.glViewport(0, 0, width, height)
        gl.glMatrixMode(GL10.GL_PROJECTION)
        gl.glLoadIdentity()
        GLU.gluOrtho2D(gl, -1f, 1f, -1f, 1f)
        gl.glMatrixMode(GL10.GL_MODELVIEW)
        gl.glLoadIdentity()
    }
override fun onDrawFrame(gl: GL10) {
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT)

        val now = System.nanoTime()

        while (now - lastSampleTime >= sampleIntervalNs) {

            // Try to read new SpO2 data
            val newValue = queue.poll()

            if (newValue != null) {
                lastSpo2Value = newValue
            }

            // Always advance waveform (this spreads width)
            lastSpo2Value?.let {
                line.addSample(it)
            }

            lastSampleTime += sampleIntervalNs
        }

        line.draw(gl)
    }



    */
/*override fun onDrawFrame(gl: GL10) {
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT)

        val now = System.nanoTime()

        while (now - lastSampleTime >= sampleIntervalNs) {

            // ---- interpolation running ----
            if (lastSpo2Value != null && interpIndex < interpSteps){

                val next = lastSpo2Value!!
                val target = queue.peek() ?: next

                val step =
                    next + (target - next) * (interpIndex + 1) / interpSteps

                line.addSample(step)
                interpIndex++

            } else {
                // ---- new real sample ----
                queue.poll()?.let { newValue ->
                    lastSpo2Value = newValue
                    interpIndex = 0
                }
            }

            lastSampleTime += sampleIntervalNs
        }

        line.draw(gl)
    }*//*

}

*/




//new


class GLRenderer2 : GLSurfaceView.Renderer {

    private val line = Line2()
    private val queue = ConcurrentLinkedQueue<Float>()

    // ---- ECG master clock ----
    private val sampleIntervalNs = 4_000_000L   // 250 Hz
    private var lastSampleTime = 0L

    private var started = false

    // ---- SpO₂ interpolation ----
    private val SPO2_RATE = 110f
    private val ECG_RATE = 250f
    private val HOLD_COUNT = (ECG_RATE / SPO2_RATE).toInt()

    private var holdCounter = 0
    private var currentValue: Float? = null


    fun addPoint(value: Float) {
        Log.d("SPO2_IN", "value = $value")
        queue.offer(value)
    }


    override fun onSurfaceCreated(gl: GL10, config: EGLConfig) {
        lastSampleTime = System.nanoTime()

        gl.glClearColor(0f, 0f, 0f, 1f)
        gl.glEnable(GL10.GL_LINE_SMOOTH)
        gl.glHint(GL10.GL_LINE_SMOOTH_HINT, GL10.GL_NICEST)
    }

    override fun onSurfaceChanged(gl: GL10, width: Int, height: Int) {
        gl.glViewport(0, 0, width, height)

        gl.glMatrixMode(GL10.GL_PROJECTION)
        gl.glLoadIdentity()
        GLU.gluOrtho2D(gl, -1f, 1f, -1f, 1f)

        gl.glMatrixMode(GL10.GL_MODELVIEW)
        gl.glLoadIdentity()
    }

    override fun onDrawFrame(gl: GL10) {
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT)

        val now = System.nanoTime()

        while (now - lastSampleTime >= sampleIntervalNs) {

            // ---- start only after first value ----
            if (currentValue == null) {
                currentValue = queue.poll()
                lastSampleTime += sampleIntervalNs
                continue
            }

            // ---- HOLD LOGIC ----
            if (holdCounter == 0) {
                queue.poll()?.let {
                    currentValue = it
                }
                holdCounter = HOLD_COUNT
            }

            line.addSample(currentValue!!)
            holdCounter--

            lastSampleTime += sampleIntervalNs
        }

        line.draw(gl)
    }
}
