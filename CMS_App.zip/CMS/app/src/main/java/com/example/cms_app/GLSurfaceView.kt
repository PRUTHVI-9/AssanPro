package com.example.cms_app

import android.content.Context
import android.opengl.GLSurfaceView
import android.util.AttributeSet
import android.util.Log
import com.example.ecgapp.GLRenderer1

class OpenGLSurfaceViewCombined @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : GLSurfaceView(context, attrs) {

    private val renderer: GLRendererCombined

    init {

        val metrics = context.resources.displayMetrics
        val xdpi = metrics.xdpi

        Log.d("SCREEN_INFO", "xdpi = $xdpi")


        setEGLContextClientVersion(1)
        renderer = GLRendererCombined()
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    fun addECG(value: Float) {
        renderer.addECG(value)
    }
    fun  addECGII(value: Float){
        renderer.addECG(value)
    }
    fun addSPO2(value: Float) {
        renderer.addSPO2(value)
    }

    fun resetwaveform(){
        queueEvent {
            //  renderer.resetWaveform()
        }
    }
}

