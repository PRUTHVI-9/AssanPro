package com.example.cms_app.view.Fragment

import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.example.cms_app.R
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.navigation.NavigationView

class Combine_Main_Activity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_combine_main)
//        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        drawerLayout = findViewById(R.id.drawerLayout)
        navigationView = findViewById(R.id.navigationView)

        navigationView.itemIconTintList = null

        replaceFragment(MonitorFragment())

        navigationView.setNavigationItemSelectedListener {

            when (it.itemId) {
                R.id.nav_monitor -> replaceFragment(MonitorFragment())
                R.id.nav_events -> replaceFragment(EventFragment())
                R.id.nav_trends -> replaceFragment(TrendsFragment())
                R.id.nav_Alarm -> replaceFragment(Alarm_settingFragment())
                R.id.nav_AlarmSound -> replaceFragment(Alarm_SoundFragment())
                R.id.nav_Prescription -> replaceFragment(Alarm_PrescriptionFragment())
            }
            drawerLayout.closeDrawers()
            true
        }
    }

    fun openDrawer() {
        drawerLayout.openDrawer(GravityCompat.START)
    }

    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, fragment)
            .commit()
    }
}