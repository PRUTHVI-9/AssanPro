package com.example.cms_app.data.model
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.cms_app.Helper.MqttManager
import com.example.cms_app.R
import com.example.cms_app.data.TrendData
import com.example.cms_app.utilis.AppLifecycleTracker
import com.example.cms_app.utilis.MqttConfig
import com.example.cms_app.view.MyBedActivity
import dagger.hilt.android.lifecycle.HiltViewModel
import jakarta.inject.Inject
import org.json.JSONObject

@HiltViewModel
class MqttViewModel @Inject constructor() : ViewModel() {

    companion object {
        val mqttData = MutableLiveData<Pair<String, String>>()
        val connectionStatus = MutableLiveData<Boolean>()
    }

    private val shownAlarms = HashMap<String, Long>()
    private val trendBuffer = ArrayDeque<TrendData>()

    fun startMqtt(userId: String, password: String, context: Context) {

        val topics = MqttConfig.getTopics(userId)

        MqttManager.connect(userId, password, topics) { topic, payload ->

            connectionStatus.postValue(true)

            mqttData.postValue(Pair(topic, payload))

            checkAlarm(topic, payload, context)
        }
    }

    private fun checkAlarm(topic: String, msg: String, context: Context) {

        try {
            val root = JSONObject(msg)

            if (!root.has("alarms")) return

            val alarms = root.getJSONObject("alarms")

            val patientName =
                root.optJSONObject("patient")
                    ?.optString("name", "")
                    ?.trim()
                    ?.ifEmpty { "Patient" }
                    ?: "Patient"

            val keys = alarms.keys()

            while (keys.hasNext()) {

                val key = keys.next()
                val value = alarms.optInt(key, 0)

                if (value > 0) {

                    val now = System.currentTimeMillis()

                    val uniqueKey = "${patientName}_$key"

                    val lastTime = shownAlarms[uniqueKey] ?: 0L

                    if (now - lastTime > 60000) {

                        shownAlarms[uniqueKey] = now

                        if (!AppLifecycleTracker.isAppInForeground) {

                            showAlarmNotification(
                                context,
                                patientName,
                                key.replace("_", " ").uppercase()
                            )
                        }
                    }
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showAlarmNotification(context: Context, patientName: String, alarmText: String) {

        val channelId = "alarm_channel"

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            val channel = NotificationChannel(channelId, "CMS Alarm", NotificationManager.IMPORTANCE_HIGH)

            channel.enableVibration(true)

            channel.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), null)

            manager.createNotificationChannel(channel)
        }

        val intent = Intent(context, MyBedActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context, patientName.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ecgicon)
            .setContentTitle("🚨 Patient- $patientName")
            .setContentText(alarmText)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))

        manager.notify("${patientName}_$alarmText".hashCode(), builder.build())
    }

    fun addTrendData(hr : Int , spo2 : Int , rr:Int , nibp : String){
        val now = System.currentTimeMillis()
        trendBuffer.addLast(TrendData(now,hr,spo2,rr,nibp))
        while (trendBuffer.isNotEmpty() && now - trendBuffer.first().time > 60000){
            trendBuffer.removeFirst()
        }

    }

    fun getLastMinData(): List<TrendData>{
        return trendBuffer.toList()

    }

    fun reconnect() {
        connectionStatus.postValue(false)
    }
}