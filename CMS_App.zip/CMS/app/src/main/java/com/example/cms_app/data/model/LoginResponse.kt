package com.example.cms_app.data.model
import android.os.Message
import com.google.gson.annotations.SerializedName
data class LoginResponse (
    @SerializedName("status")
    val status: Boolean,
    @SerializedName("message")
    val message: String,
    @SerializedName("emp_id")
    val empId: String
)


