package com.example.cms_app
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max
import kotlin.math.min

class Line {

    private val totalPoints = 1000        // 4 sec × 250 Hz
    private val vertexBuffer: FloatBuffer

    private var writeIndex = 0
    private var filledPoints = 0

    private var minVal = Float.MAX_VALUE
    private var maxVal = Float.MIN_VALUE

    init {
        vertexBuffer = ByteBuffer
            .allocateDirect(totalPoints * 3 * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()

        // fixed X axis ( pixels_per_second logic)
        for (i in 0 until totalPoints) {
            val x = -1f + 2f * i / (totalPoints - 1)
            vertexBuffer.put(i * 3, x)
            vertexBuffer.put(i * 3 + 1, 0f)
            vertexBuffer.put(i * 3 + 2, 0f)
        }
    }

    fun addSample(value: Float) {
        minVal = min(minVal, value)
        maxVal = max(maxVal, value)

        val amp = max(1f, maxVal - minVal)
        val norm = (value - minVal) / amp          // 0..1
        val y = (norm - 0.5f) * 0.5f                // centered, gain

        val offset = writeIndex * 3
        vertexBuffer.put(offset + 1, y)

        writeIndex = (writeIndex + 1) % totalPoints
        if (filledPoints < totalPoints) filledPoints++

        onSampleReceived()
    }

    fun draw(gl: GL10) {
        if (filledPoints < 2) return

        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY)
        gl.glLineWidth(2f)
        gl.glColor4f(0f, 1f, 0f, 1f) // ECG green

        vertexBuffer.position(0)
        gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuffer)

        // ----  break on cursor ----

        // right side (new data)
        if (writeIndex > 1) {
            gl.glDrawArrays(
                GL10.GL_LINE_STRIP,
                0,
                writeIndex
            )
        }

        // left side (old data)
        if (filledPoints > writeIndex + 1) {
            gl.glDrawArrays(
                GL10.GL_LINE_STRIP,
                writeIndex,
                filledPoints - writeIndex
            )
        }

        gl.glDisableClientState(GL10.GL_VERTEX_ARRAY)
    }
    private var sampleCounter = 0
    private var lastTime = System.currentTimeMillis()

    fun onSampleReceived() {
        sampleCounter++

        val now = System.currentTimeMillis()
        if (now - lastTime >= 1000) {
            Log.d("SAMPLE_RATE", "Samples per second ecg = $sampleCounter")
            sampleCounter = 0
            lastTime = now
        }
    }
}
